<?php namespace Controllers;


use  Models\Offices as Offices;

class offices_{

	private $offices;

	public function index(){
		include_once('Views/offices.php');
	}

	public function __construct(){
		$this->offices = new Offices();
	}

	public function add(){
		include_once('Views/register_offices.php');
	}

	public function register(){
		$id_vet = (isset($_POST['id_vet'])) ? $_POST['id_vet'] : "";
		$this->offices->set('id_vet',$id_vet);
		$address = (isset($_POST['address'])) ? $_POST['address'] : "";
		$this->offices->set('address',$address);
		$hours = (isset($_POST['hours'])) ? $_POST['hours'] : "";
		$this->offices->set('hours',$hours);
		$home_service = (isset($_POST['home_service'])) ? $_POST['home_service'] : "";
		$this->offices->set('home_service',$home_service);
		$em = (isset($_POST['em'])) ? $_POST['em'] : "";
		$this->offices->set('em',$home_service);
		$telefono = (isset($_POST['telefono'])) ? $_POST['telefono'] : "";
		$this->offices->set('telefono',$telefono);
		$email = (isset($_POST['email'])) ? $_POST['email'] : "";
		$this->offices->set('email',$email);
		$ciudad = (isset($_POST['ciudad'])) ? $_POST['ciudad'] : "";
		$this->offices->set('ciudad',$ciudad);
		$barrio = (isset($_POST['barrio'])) ? $_POST['barrio'] : "";
		$this->offices->set('barrio',$barrio);
		$response = $this->offices->add();

		if($response){
			if($response->rowCount() > 0){
				echo 'success';
			}else{
				echo 'failed';
			}
		}


	}


	public function list_all(){
		$response = $this->offices->list_all();
		if($response){
			if($response->rowCount() > 0){
				echo json_encode($response->fetchAll(\PDO::FETCH_ASSOC));
			}else{
				echo json_encode(array('data' => 'empty'));
			}
		}
	}
}



 ?>