<?php namespace Controllers;

//use Models\Pets as Pets;
use Models\Medical_history as Medical_history;
use Models\Veterinarians as Veterinarians;

class medical_history_{

	//ATTRIBUTES;
	private $medical_history;
	private $veterinarians;


	public function __construct(){
		//INIT OBJECT
		$this->medical_history = new Medical_history();
		$this->veterinarians   = new Veterinarians();
	}


	//LOAD INTERFACE
	public function index(){
		include_once('Views/medical_history.php');
	}


	public function display_form(){
		$pet = (isset($_GET['pet'])) ? $_GET['pet']  : "";
		$reg = (isset($_GET['reg'])) ? $_GET['reg']  : "";
		$vet = (isset($_GET['vet']))  ? $_GET['vet'] : "";

		if(empty($pet) && empty($reg) && empty($vet)){
			//echo 'display:none;';
		}else if(empty($vet)){
			echo 'display:block;';
		}else{
			echo 'display:none;';
		}
	}


	


	public function list(){

		$id = (isset($_GET['pet'])) ? $_GET['pet'] : "";

		if(!empty($id)){
			$this->medical_history->set("id_pet",$id);
			$response = $this->medical_history->list_data();	
			
			
			if($response){
				return $response;
			}

		}
			
	}


	public function add_V(){
		
		$code =    2222;
		$this->veterinarians->set("codigo",$code);

		$id_pet =  (isset($_POST['id_pet'])) ? $_POST['id_pet'] : "";
		$this->medical_history->set('id_pet',$id_pet);

		$name_v = (isset($_POST["name_v"])) ? $_POST["name_v"] : "";
		$this->veterinarians->set("nombre",$name_v);

		$sexo = (isset($_POST["sex_v"])) ? $_POST["sex_v"] : "";
		$this->veterinarians->set("genero",$sexo);

		$telefono = (isset($_POST["phone_v"])) ? $_POST["phone_v"] : "";
		$this->veterinarians->set("telefono",$telefono);
	    $direccion = (isset($_POST["direccion_v"])) ? $_POST["direccion_v"] : "";
		$this->veterinarians->set("direccion",$direccion);
		$email =  (isset($_POST["email_v"]))  ? $_POST["email_v"] : "";
		$this->veterinarians->set("email",$email);
		$password 	 = 	"123456";
		$this->veterinarians->set("password",$password);

		$ciudad = (isset($_POST["city_v"])) ? $_POST["city_v"] : "";
		$this->veterinarians->set("ciudad",$ciudad);

		$neit_lender = 	  "No lo se";
		$this->veterinarians->set("barrio",$neit_lender);
	
		
		$comentarios = 'Por que estoy interesado';
		$this->veterinarians->set('comentarios',$comentarios);
		$picture = "img/user.png";
		$this->veterinarians->set("picture",$picture);

	

		
		
		
		
		
		// $whatsapp = (isset($_POST["whatsapp_v"])) ? $_POST["whatsapp_v"] : "";
		// $this->medical_history->set("whatsapp_v",$whatsapp);
		// $c_v     = (isset($_POST['cer_v'])) ? $_POST['cer_v']   : "";
		// $this->medical_history->set("certificado_v",$c_v);
		// echo $c_v;
		// $hemo  = (isset($_POST['hemo'])) ? $_POST['hemo'] : "";
		// echo $hemo."-";
		// $this->medical_history->set("hemograma",$hemo);
		// $hemop  = (isset($_POST['hemop'])) ? $_POST['hemop'] : "";
		// echo $hemop."-";
		// $this->medical_history->set("hemoparasito",$hemop);

		$response = $this->veterinarians->add();

		if($response){
			if($response->rowCount() > 0){
				echo "success";
			}else{
				echo "failed";
			}
		}

	}


	public function update_add(){

		$c_v     = (isset($_POST['cer_v'])) ? $_POST['cer_v']   : "";
		$ser_sp  = (isset($_POST['ser_sp'])) ? $_POST['ser_sp'] : "";
		$hemo  = (isset($_POST['hemo'])) ? $_POST['hemo'] : "";
		$hemop  = (isset($_POST['hemop'])) ? $_POST['hemop'] : "";

	}



}


 ?>