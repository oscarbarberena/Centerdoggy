<?php namespace Controllers;


use Models\Users as Users;
use Models\Lenders as Lenders;
use Models\Owners as Owners;
use Models\Calendar as Calendar;

class profile{

	private $users;
	private $lenders;
	private $owners;
	private $calendar;


	public function __construct(){
		$this->users = new Users();
		$this->lenders = new Lenders();
		$this->owners = new Owners();
		$this->calendar = new Calendar();
	}

	public function index(){
		include_once('Views/view_users.php');
	}

	public function view($id){
		if(!empty($id) || $id != null){
			include_once('Views/profile_user.php');
		}else{
			echo "Page no found";
		}
	}

	public function view_owner($id){
		if(!empty($id) || $id != null){
			include_once('Views/profile_owner.php');
		}else{
			echo "Page no found";
		}
	}

	public function view_horario(){
		include_once('Views/view_horario.php');
	}


	/* METHODS FOR LIST INFO*/

	public function load_info_current_user(){
		$url = $_SERVER['REQUEST_URI'];
		$split = explode("/", $url);

		if(count($split) >= 4){	
			$this->users->set("id",$split[3]);
			$result = "";
			
			if($_SESSION['location'] == "lenders"){
				$result = $this->users->list("lenders");	
			}else if($_SESSION['location'] == "owners"){
				$result = $this->users->list("owners");	
			}
			

			return $result->fetch();
		}
		
		
	}

	public function get_info_lenders(){
		$url = $_SERVER['REQUEST_URI'];
		$split = explode("/", $url);

		if(count($split) >= 5){	
			$this->users->set("id",$split[4]);
			$result = $this->users->list("lenders");	
			

			return $result->fetch();
		}
	}


	public function get_info_owner(){
		$url = $_SERVER['REQUEST_URI'];
		$split = explode("/", $url);

		if(count($split) >= 5){	
			$this->users->set("id",$split[4]);
			$result = $this->users->list("owners");	
			

			return $result->fetch();
		}
	}



	/* METHODS FOR UPDATE INFO*/

	public function edit_lender(){
		
		$code = isset($_POST['code_us']) ? $_POST['code_us'] : "";
		$this->lenders->set("code",$code);
		$name = (isset($_POST['name_us'])) ? $_POST['name_us'] : "";
		echo $name."-";
		$this->lenders->set("name",$name);
		$sexo = (isset($_POST['sex_us'])) ? $_POST['sex_us'] : "";
		$this->lenders->set("sex",$sexo);
		$email = (isset($_POST['email_us'])) ? $_POST['email_us'] : "";
		$this->lenders->set("email",$email);
		$city = (isset($_POST['city_us'])) ? $_POST['city_us'] : "";
		$this->lenders->set("city_lender",$city);
		$neit = (isset($_POST['neit_us'])) ? $_POST['neit_us'] : "";
		$this->lenders->set("neit_lender",$neit);
		$phone = (isset($_POST['phone_us'])) ? $_POST['phone_us'] : "";
		$this->lenders->set("phone",$phone);
		$id = isset($_POST['id_user']) ? $_POST['id_user'] : "";
		$this->lenders->set('id',$id);

		$response = $this->lenders->update_lenders();

		if($response){
			if($response->rowCount() > 0){
				echo "success";
			}else{
				echo "failed";
			}
		}

	}

	public function edit_owner(){
		session_start();
		$name = (isset($_POST['name_us'])) ? $_POST['name_us'] : "";
		echo $name."-";
		$this->owners->set("name",$name);
		$sexo = (isset($_POST['sex_us'])) ? $_POST['sex_us'] : "";
		$this->owners->set("sex",$sexo);
		$email = (isset($_POST['email_us'])) ? $_POST['email_us'] : "";
		$this->owners->set("email",$email);
		$city = (isset($_POST['city_us'])) ? $_POST['city_us'] : "";
		$this->owners->set("city_owner",$city);
		$neit = (isset($_POST['neit_us'])) ? $_POST['neit_us'] : "";
		$this->owners->set("neit_owner",$neit);
		$phone = (isset($_POST['phone_us'])) ? $_POST['phone_us'] : "";
		$this->owners->set("phone",$phone);
		$id = isset($_SESSION['id_user']) ? $_SESSION['id_user'] : "";
		$this->owners->set('id',$id);

		$response = $this->owners->update_owners();

		if($response){
			if($response->rowCount() > 0){
				echo "success";
			}else{
				echo "failed";
			}
		}

	}

	public function load_horario(){
		session_start();
		$id_user = (isset($_SESSION['id_user'])) ? $_SESSION['id_user'] : "";
		$this->calendar->set('id_user',$id_user);
		$day     = (isset($_POST['day'])) ? $_POST['day'] : "";
		$this->calendar->set('day',$day);
		$response = $this->calendar->get_horario_user();

		if($response){
			if($response->rowCount() > 0){
				echo json_encode($response->fetchAll(\PDO::FETCH_ASSOC));
			}else{
				echo "failed empty";
			}
		}
	}


}




 ?>