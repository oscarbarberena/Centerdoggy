<?php namespace Controllers;

use Models\Owners as Owners;

class register_owner{


	private $owners;

	public function index(){
		include_once('Views/register_owner.php');
	}

	
	public function __construct(){
		$this->owners = new Owners();
	}

	public function add_owner(){
		$name_owner =     (isset($_POST['name_owner'])) ? $_POST['name_owner'] : "";
		$this->owners->set("name",$name_owner);
		$sex 		 = 	   (isset($_POST['sex'])) ? $_POST['sex'] : "";
		$this->owners->set("sex",$sex);
		$email 		 =     (isset($_POST['email'])) ? $_POST['email'] : "";
		$this->owners->set("email",$email);
		$password 	 = 	   (isset($_POST['password'])) ? $_POST['password'] : "";
		$this->owners->set("password",$password);
		$city_owner = 	   (isset($_POST['city_owner'])) ? $_POST['city_owner'] : "";
		$this->owners->set("city_owner",$city_owner);
		$neit_owner = 	   (isset($_POST['neit_owner'])) ? $_POST['neit_owner'] : "";
		$this->owners->set("neit_owner",$neit_owner);
		$phone 		 = 	   (isset($_POST['phone'])) ? $_POST['phone'] : "";
		$this->owners->set("phone",$phone);
		$picture = "";
		$this->owners->set("picture",$picture);
		$status 	 =      "no active";
		$this->owners->set("status",$status);
		$type_user 	 = 2;
		$this->owners->set("type_user",$type_user);

		$call = $this->owners->add();

		if($call){
			if($call->rowCount() > 0){
				echo "success";
			}else{
				echo "failed";
			}
		}

	}

	public function edit_lender($arg){
		
		$id_user = 0;

		if($arg == "default"){
			$id_user = isset($_SESSION['id_user']) ? $_SESSION['id_user'] : "";
			$name_owner =     (isset($_POST['name_owner'])) ? $_POST['name_owner'] : "";
			$this->owners->set("name",$name_owner);
			$this->owners("id",$id_user);
			$response = $this->owners->edit();

				if($response){
						if($response->rowCount() > 0){
							echo "success";
						}else{
							echo "failed";
						}
				}
		}else{
			$id_user =  isset($_POST['id_user']) ? $_POST['id_user'] : "";
			$this->owners("id",$id_user);
			$response = $this->owners->edit();

				if($response){
						if($response->rowCount() > 0){
							echo "success";
						}else{
							echo "failed";
						}
				}


		}


	}


	public function delete_owner(){
		$id_user =  isset($_POST['id_user']) ? $_POST['id_user'] : "";
		$response = $this->lenders->delete();

		if($response){
			if($response->rowCount() > 0){
				echo "success";
			}else{
				echo "failed";
			}
		}
	}
}



 ?>