<?php namespace Controllers;


class portal_modules{

	public function index(){
		include_once('Views/portal_modules.php');
	}
}



 ?>