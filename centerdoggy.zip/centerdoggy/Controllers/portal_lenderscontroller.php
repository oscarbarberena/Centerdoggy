<?php namespace Controllers;

use Models\Users as Users;
use Models\Calendar as Calendar;

class portal_lenders{

	private $users;
	private $calendar;

	public function __construct(){
		$this->users = new Users();
		$this->calendar = new Calendar();
	}

	public function index(){
		include_once('Views/portal_lenders.php');
	}


	public function getinfo($id,$param){
		$this->users->set("id",$id);
		$row =  $this->users->list($param);

		return $row->fetch();
	}

	public function count_request_service($id){
		$id_user = (isset($_SESSION['id_user'])) ? $_SESSION['id_user'] : '';
		$this->calendar->set('id_user',$id_user);
		$id_service = (isset($id)) ? $id : "";
		$this->calendar->set('id_service',$id_service);
		$response = $this->calendar->list_request_service();

		if($response){
			if($response->rowCount() > 0){
				return $response->rowCount();
			}else{
				return 0;
			}
		}
	}
}


 ?>