<?php namespace Controllers;


class lenders{
	public function index(){
		include_once('Views/lenders.php');
	}

	public function add(){
		include_once('Views/register_lender.php');
	}

	public function formtwo(){
		include_once('Views/form2.php');
	}
}

 ?>