<?php namespace Controllers;


use Models\Lenders as Lenders;
use Models\Calendar as Calendar;
use Models\Pets as Pets;

class calendar_lender{

	private $lenders;
	private $calendar;
	private $pets;

	public function index(){
		include_once('Views/calendar_lender.php');
	}

	public function view_calendar(){
		include_once('Views/clender_current.php');	
	}

	public function select_working_hours(){
		include_once('Views/select_working_hours.php');
	}

	public function __construct(){
		$this->lenders  = new Lenders();
		$this->calendar = new Calendar();
		$this->pets     = new Pets();
	}


	public function add_days(){

		$month = (isset($_POST['month'])) ? $_POST['month']  : "";
		$code_user   = isset($_POST['code']) ? $_POST['code'] : "";
		$id_user 	 = $this->lenders->listcode($code_user)['id_lender'];
		$this->calendar->set("id_user",$id_user);
		$days 		 = (isset($_POST['weekday'])) ? $_POST['weekday'] : "";
		$days_ = array_filter(explode("-",preg_replace('/[^0-9]+/',"-",str_replace(")","",str_replace("(", "", $days)))),"strlen");
		$this->calendar->set("id_weekdays",$days_);
		$response  = $this->calendar->addDays();
		
					//echo "/centerdoggy/calendar_lender/select_working_hours/?id_lender=".$id_user."&id_days=".$id_days."&month=".$month;
		

		 if($response){
				
				if($response->rowCount() > 0){	
					echo "/centerdoggy/calendar_lender/select_working_hours/?id_lender=".$id_user."&month=".$month;

				}else{
					echo "failed";
				}
			}
			
	}

	public function get_total_hours(){
		$response = $this->calendar->get_total_work_hours();

		if($response){
				if($response->rowCount() > 0){
					while($row = $response->fetch()){
						echo '<div class="list_option">
		                    		<a href="/centerdoggy/my_pets/add/" class="link_ range_days" data-hour="'.$row["id_hour"].'">'.$row["range_time"].'</a>
		                      </div>';
						
						
					}
				}else{
					echo "no hay nada";
				}
		}
	}


	public function list_days_work_lender(){
		$id = isset($_GET["id_lender"]) ? $_GET["id_lender"] : "";
		$this->calendar->set("id_user",$id);
		$response = $this->calendar->list_days_work_lender();
		if($response){
			if($response->rowCount() > 0){
					$count = 0;
					while($row = $response->fetch()){
						echo '<div class="list_option">
		                    		<a href="/centerdoggy/my_pets/add/" class="link_ days_choosed" data-day="'.$row["id_day"].'" data-index="'.$count.'">'.$row["name_weekday"].'</a>
		                      </div>';
		                      $count++;
					}
			}else{

			}
		}
	}



	


	public function add_schedule_lender(){
		$id_user     = isset($_POST['id_lender']) ? $_POST['id_lender'] : "";
		$field_day   = isset($_POST['field_day']) ? $_POST['field_day'] : "";
		$this->calendar->set('id_weekdays',$field_day);
		$month 		 = isset($_POST['month']) ? $_POST['month'] : "";
		$this->calendar->set('id_month',$month);
		$start_time = isset($_POST['start_time']) ? $_POST['start_time'] : "";
		$end_time   = isset($_POST['end_time']) ? $_POST['end_time'] : "";
		//$this->get_IdHours($start_time,$end_time);
		$range_time = array($start_time,$end_time);
		$this->calendar->set('start_time',$range_time);
		$date_ 		 = date('d/m/Y H:i:s');
		$this->calendar->set('date_create',$date_);
		$response = $this->calendar->addslender();
	
		
		if($response){
			if($response->rowCount() > 0){
				session_start();
				$_SESSION['id_user'] = $id_user;
				echo "http://localhost:8089/centerdoggy/portal_lenders/";
			}else{
				echo "failed";
			}
		}

 	}


 	public function info_lender_current($id){
 		$this->lenders->set("id",$id);
 		$result = $this->lenders->list("diferent");
 		return $result->fetch();
 	}


 	public function getschedule_current_lender($id){
 		$this->lenders->set("id",$id);
 		$result = $this->lenders->getschedule_lender();
 		echo json_encode($result->fetchAll(\PDO::FETCH_ASSOC));
 	}

 	public function getschedule_lender_disabled(){
 		$result = $this->lenders->day_disabled();
 		echo json_encode($result->fetchAll(\PDO::FETCH_ASSOC));
 	}

 	public function get_position_day($day){
 		switch ($day) {
 			case 'LUNES':
 				# code...
 				return 1;
 				break;
 			case 'MARTES':
 				return 2;
 				break;
 			case 'MIERCOLES':
 				 return 3;
 				 break;
 			case 'JUEVES':
 				 return 4;
 				 break;	 		
 			case 'VIERNES':
 				return 5;
 				break;
 			case 'SABADO':
 				 return 6;
 				 break;	
 			default:
 				# code...
 				break;
 		}
 	}

 	public function getschedule_hours_days_available(){
 		$id = (isset($_POST["id_lender"])) ? $_POST["id_lender"] : "";
 		$this->calendar->set('id_user',$id);
 		$month = (isset($_POST["month"])) ? $_POST["month"] : "0";
 		$this->calendar->set('id_month',$month);
 		$day = (isset($_POST["day"])) ? $_POST["day"] : "";
 		$this->calendar->set('id_weekdays',$this->get_position_day($day));

 		
 		$response = $this->calendar->getschedule_hours_days_available();

 		if($response){
 			if($response->rowCount() > 0){
 				echo json_encode($response->fetchAll(\PDO::FETCH_ASSOC));
 			}else{

 				echo json_encode([array('id_schedule' => 0, 'range_time' => 'El prestador en este diá no esta disponible')]);
 			}
 		}


 	}

 	public function load_all_pets(){
		session_start();
		$id = isset($_SESSION["id_user"]) ? $_SESSION["id_user"] : "";

		$this->pets->set("id_owner",$id);
		$response = $this->pets->load_allPets();
		if($response){
			if($response->rowCount() > 0){
				echo json_encode($response->fetchAll(\PDO::FETCH_ASSOC));
			}else{
				echo json_encode(array('data' => 'empty'));
			}
		}
		
	}	


	public function add_schedule_service(){
		$id_pet = (isset($_POST['id_pet'])) ? $_POST['id_pet'] : "";
		$this->calendar->set('id_pet',$id_pet);
		$day = (isset($_POST['day'])) ? $_POST['day'] : "";
		$this->calendar->set('day',$day);
		$id_user = (isset($_POST['id_suser'])) ? $_POST['id_suser'] : "";
		$this->calendar->set('id_user',$id_user);
		$id_service = (isset($_POST['id_service'])) ? $_POST['id_service'] : "";
		$this->calendar->set('id_service',$id_service);
		$date_c   = date('d/m/Y H:i:s');
		$this->calendar->set('date_create',$date_c);
		$date_up   = date('d/m/Y H:i:s');
		$this->calendar->set('date_update',$date_up);
		$response = $this->calendar->add_schedule_service();
		
		if($response){
			if($response->rowCount() > 0){
				echo "success";
			}else{
				echo "failed";
			}
		}

	}


	public function list_request_service(){
		$id_user = (isset($_SESSION['id_user'])) ? $_SESSION['id_user'] : '';
		$this->calendar->set('id_user',$id_user);
		$response = $this->calendar->list_request_service();

		if($response){
			if($response->rowCount() > 0){
				$count = 1;
				while($row = $response->fetch()){
					if($count > 1){
						echo '<div class="list_info color">
							<li class="list_">
								<p class="info_">'.$count.'</p>
							</li>
							<li class="list_">
								<p class="info_">'.$row["name_owner"].'</p>
							</li>
							<li class="list_">
								<p class="info_">'.$row["name_pet"].'</p>
							</li>
							<li class="list_">
								<p class="info_">'.$row["day_service"].'</p>
							</li>
							<li class="list_">
								<p class="info_">Activo</p>
							</li>
						</div>';
					}else{
						echo '<div class="list_info">
							<li class="list_">
								<p class="info_">'.$count.'</p>
							</li>
							<li class="list_">
								<p class="info_">'.$row["name_owner"].'</p>
							</li>
							<li class="list_">
								<p class="info_">'.$row["name_pet"].'</p>
							</li>
							<li class="list_">
								<p class="info_">'.$row["day_service"].'</p>
							</li>
							<li class="list_">
								<p class="info_">Activo</p>
							</li>
						</div>';
					}
					
						$count++;
				}
			}else{
				echo "No hay solicitudes para este servicio";
			}
		}
	}


}



 ?>