<?php namespace Controllers;

use Models\Users as Users;

class portal_owner{

	private $users;

	public function __construct(){
		$this->users = new Users();
	}


	public function index(){
		include_once('Views/portal_owner.php');
	}

	public function getinfo($id,$param){
		$this->users->set("id",$id);
		$row =  $this->users->list($param);

		return $row->fetch();
	}

	public function search_owner_for_name(){
		$name = (isset($_POST['name'])) ? $_POST['name'] : "none";
		$this->users->set('name',$name);
		$response = $this->users->search_for_name();

		if($response){
			if($response->rowCount() > 0){
				echo json_encode($response->fetchAll(\PDO::FETCH_ASSOC));
			}else{
				echo "empty";
			}
		}
	}


}


 ?>