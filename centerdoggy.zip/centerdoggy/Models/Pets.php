<?php namespace Models;


class Pets{

	private $id_pet;
	private $name_pet;
	private $date_pet;
	private $color;
	private $picture;
	private $id_owner;

	private $con_;


	public function set($attr,$value){
		$this->$attr = $value;
	}


	public function get($attr){
		return $this->$attr;
	}
	public function __construct(){
		$this->con_ = new Connection();
	}


	public function add_pets(){
		$sql  = 'INSERT INTO pets VALUES(NULL,:name,:date_pet,:color,:picture,:id_owner)';
		$stmt = $this->con_->prepare($sql);
		$stmt->bindParam(':name',$this->name_pet,\PDO::PARAM_STR);
		$stmt->bindParam(':date_pet',$this->date_pet,\PDO::PARAM_STR);
		$stmt->bindParam(':color',$this->color,\PDO::PARAM_STR);
		$stmt->bindParam(':picture',$this->picture,\PDO::PARAM_STR);
		$stmt->bindParam(':id_owner',$this->id_owner,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}


	public function list(){
		$sql = "SELECT * FROM pets";
		$stmt = $this->con_->prepare($sql);
		$stmt->bindParam(':id',$this->id_owner,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}

	public function list_(){
		$sql = "SELECT * FROM pets WHERE id_pet =:id";
		$stmt = $this->con_->prepare($sql);
		$stmt->bindParam(':id',$this->id_pet,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}

	public function load_allPets(){
		$sql = "SELECT * FROM pets WHERE id_owner =:id";
		$stmt = $this->con_->prepare($sql);
		$stmt->bindParam(':id',$this->id_owner,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;

	}

	public function delete(){
		$sql = "DELETE FROM pets WHERE id_pet =:id";
		$stmt = $this->con_->prepare($sql);
		$stmt->bindParam(':id',$this->id_pet,\PDO::PARAM_INT);
		$stmt->execute();

		return $stmt;
	}

	public function update_info(){
		$sql = 'UPDATE pets SET name_pet =:name, date_nacimiento =:date_, color =:color,picture =:picture WHERE id_pet =:id';
		$stmt = $this->con_->prepare($sql);
		if(!empty($this->picture)){
			$stmt->bindParam(':name',$this->name_pet,\PDO::PARAM_STR);
			$stmt->bindParam(':date_',$this->date_pet,\PDO::PARAM_STR);
			$stmt->bindParam(':color',$this->color,\PDO::PARAM_STR);
			$stmt->bindParam(':picture',$this->picture,\PDO::PARAM_STR);
			$stmt->bindParam(':id',$this->id_pet,\PDO::PARAM_INT);
		}else{
			$stmt->bindParam(':name',$this->name_pet,\PDO::PARAM_STR);
			$stmt->bindParam(':date_',$this->date_pet,\PDO::PARAM_STR);
			$stmt->bindParam(':color',$this->color,\PDO::PARAM_STR);
			$stmt->bindParam(':id',$this->id_pet,\PDO::PARAM_INT);

		}

		$stmt->execute();

		return $stmt;
	}

} 




 ?>