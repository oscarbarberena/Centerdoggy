<?php namespace Models;



class Offices{

	private $conexion;

	#Attributes
	private $id_vet;
	private $address;
	private $hours;
	private $em;
	private $home_service;
	private $telefono;
	private $email;
	private $ciudad;
	private $barrio;
	


	public function __construct(){
		$this->conexion = new Connection();
	}


	public function set($attr,$value){
		$this->$attr = $value;
	}


	public function add(){
		$sql = 'INSERT INTO offices_veterinarians VALUES(NULL,:id_vet,:ad,:hours,:hserv,:em,:telefono,:email,:ciudad,:neit)';
		$stmt = $this->conexion->prepare($sql);
		
		$stmt->bindParam(':id_vet',$this->id_vet,\PDO::PARAM_INT);
		$stmt->bindParam(':ad',$this->address,\PDO::PARAM_STR);
		$stmt->bindParam(':hours',$this->hours,\PDO::PARAM_STR);
		$stmt->bindParam(':hserv',$this->home_service,\PDO::PARAM_STR);
		$stmt->bindParam(':em',$this->em,\PDO::PARAM_STR);
		$stmt->bindParam(':telefono',$this->telefono,\PDO::PARAM_INT);
		$stmt->bindParam(':email',$this->email,\PDO::PARAM_STR);
		$stmt->bindParam(':ciudad',$this->ciudad,\PDO::PARAM_STR);
		$stmt->bindParam(':neit',$this->barrio,\PDO::PARAM_STR);
		$stmt->execute();

		return $stmt;

	}

	public function list_all(){

		$sql = 'SELECT * FROM offices_veterinarians';
		$stmt = $this->conexion->prepare($sql);
		$stmt->execute();

		return $stmt;
	}


}


 ?>