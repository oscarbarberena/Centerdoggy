<?php namespace Models;


class Main{

	private $con;
	private $users_;

	public function __construct(){
		$this->con = new Connection();
		$this->users_ = new Users();
	}
	public function change_space($string){
		return str_replace(" ", '-', $string);

	}

	public function removeQuotation($string){
		return str_replace("'", "", $string);
	}

	public function hashString($cadena){
		$def__pass = password_hash($cadena, PASSWORD_DEFAULT);
		return $def__pass;
	}

	public function invertString($string){
		return strrev($string);
	}

	public function rg_users($f_name,$f_usr,$f_eml,$f_pss){
		$stmt = $this->con->prepare("INSERT INTO u_users VALUES(NULL,:name,:email,:username,:password,:picture,:id_type)");
		$name = $this->removeQuotation($this->con->proteccion($f_name));
		$usr  = $this->removeQuotation($this->con->proteccion($f_usr));
		$eml  = $this->removeQuotation($this->con->proteccion($f_eml));
		$pss  = $this->hashString($this->invertString($this->removeQuotation($this->con->proteccion($f_pss))));
		$picture = "images/user.png";
		$id_type = 2;
		$stmt->bindParam(":name",$name,\PDO::PARAM_STR);	
		$stmt->bindParam(":email",$eml,\PDO::PARAM_STR);
		$stmt->bindParam(":username",$usr,\PDO::PARAM_STR);
		$stmt->bindParam(":password",$pss,\PDO::PARAM_STR);
		$stmt->bindParam(":picture",$picture,\PDO::PARAM_STR);
		$stmt->bindParam(":id_type",$id_type,\PDO::PARAM_INT);
		$stmt->execute();

		if($stmt){
			echo "success";
		}else{
			echo "failed";
		}



	}

	public function validateLogin($username){
		$stmt = $this->con->prepare("SELECT * FROM u_users WHERE u_username =:username");
		$usr = $this->users_->setUsername($username);
		$usr = $this->removeQuotation($this->con->proteccion($this->users_->getUsername()));
		$stmt->bindParam(":username",$username);
		$stmt->execute();
		if($stmt){
			if($stmt->rowCount() > 0){
				return $stmt->fetch();
			}else{
				return "failed";
			}
		}
	}
	public function get_courses(){
		$stmt = $this->con->prepare("SELECT * FROM c_courses");
		$stmt->execute();

		if($stmt){
			if($stmt->rowCount() > 0){
				while($data = $stmt->fetch()){

			if($data["key_class"] == "php" || $data["key_class"] == "c_" || $data["key_class"] == "jquery"){
				echo '<a href="/codelines/courses/view_course/'.$this->change_space($data["c_short_name_course"]).'/" class="box_course">
					<div class="panel_head '.$data["key_class"].'">
						'.$data["c_picture_course"].'
					</div>
					<div class="panel_body">
						<h3 class="name_course">'.$data["c_name_course"].'</h3>
						<p class="short_description">'.$data["c_short_description"].'</p>
						<span class="tag_course">'.$data["c_level_course"].'</span>
					</div>
				</a>';
			}else{
				echo '<a href="/codelines/courses/view_course/'.$this->change_space($data["c_short_name_course"]).'/" class="box_course">
					<div class="panel_head '.$data["key_class"].'">
						
					</div>
					<div class="panel_body">
						<h3 class="name_course">'.$data["c_name_course"].'</h3>
						<p class="short_description">'.$data["c_short_description"].'</p>
						<span class="tag_course">'.$data["c_level_course"].'</span>
					</div>
				</a>';	
			}
			
		}
			}else{
				echo "No there courses";
			}
		}

	}


	public function course_current($name_course){
		$stmt = $this->con->prepare("SELECT * FROM c_courses WHERE c_short_name_course =:name");
		$stmt->bindParam(':name',$name_course,\PDO::PARAM_STR);
		$stmt->execute();

		if($stmt){
			if($stmt->rowCount()>0){
				return $stmt->fetch();
			}
		}

	}

	//function that add new tutorial

	public function add_new_tutorial($img_main,$title,$body,$id_user,$tags){
		$stmt = $this->con->prepare('INSERT INTO t_tutorials VALUES(NULL,:img_main,:title,:body,:id_user,:tags,:date_tutorial)');
		$title_ = $this->removeQuotation($this->con->proteccion($title));
		$date_ = date('d/m/Y G:i:d');
		$tags_ = str_replace('</span>', '-', $tags);
		$tags__ = str_replace('<span class="">', '', $tags_);
		$stmt->bindParam(':img_main',$img_main,\PDO::PARAM_STR);
		$stmt->bindParam(':title',$title_,\PDO::PARAM_STR);
		$stmt->bindParam(':body',$body,\PDO::PARAM_STR);
		$stmt->bindParam(':id_user',$id_user,\PDO::PARAM_INT);
		$stmt->bindParam(':tags',$tags,\PDO::PARAM_STR);
		$stmt->bindParam(':date_tutorial',$date_,\PDO::PARAM_STR);
		$stmt->execute();

		echo $img_main."\n".$title_."\n".$body."\n".$id_user."\n".$tags;

		if($stmt){
			echo "sucess";
		}else{
			echo "failed";
		}

	}

	public function replace_location($string){
		$f_string = str_replace('C:/xampp/htdocs/', 'http://localhost:8080/', $string);
		$s_string = str_replace('/opt/lampp/htdocs/', 'http://localhost:8080/',$f_string);

		return $s_string;
	}

	public function get_format_date($string){
		$months = array('Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre');
		$date_ = substr($string, 0, strpos($string," "));


		return "Publicado el ".$date_;
		 
	}

	public function cort_title($string){
		if(strlen($string) == 36 ){
			return substr($string, 0,35);
		}else if(strlen($string) > 36){
			return substr($string, 0,33).'...';
		}else{
			return $string;
		}
	}

	public function remove_html($string){
		$s = array('<br></b>','<br>');
		$r = array('','');

		return str_replace($s, $r, $string);

	}
	//function that load all tutorials writes

	public function load_all_tutorials(){
		$stmt = $this->con->prepare('SELECT tu.id_tutorials,tu.image_main,tu.title_,tu.info_tutorial,tu.date_tutorial, us.name_user, us.picture_, COUNT(lk.id_tutorial) as count_likes FROM t_tutorials tu INNER JOIN u_users us  ON us.id_user = tu.id_user_post LEFT JOIN likes_tutorial lk ON tu.id_tutorials = lk.id_tutorial GROUP BY tu.id_tutorials HAVING COUNT(lk.id_tutorial) >= 0 LIMIT 9');
		$stmt->execute();

		if($stmt){
			if($stmt->rowCount() > 0){
					while($data = $stmt->fetch()){
						$text = "";
						$file = file($data['info_tutorial']);


						foreach ($file as $value) {
							$text = $value;
							
						}

						echo '<a href="http://localhost:8080/codelines/tutorials/view/?id='.$data["id_tutorials"].'" class="box_t_">
									<div class="box_tutorials">
									<div class="panel_head" style="background:url('.$this->replace_location($data["image_main"]).'); background-size:100% 100%;">
										
									</div>
									<div class="panel_body">
										<h1 class="title_">'.$this->cort_title($data["title_"]).'</h1>
										<p class="info_tutorial">'.utf8_decode(strip_tags(html_entity_decode(substr($text, 0,115)))).'...</p>
										<div class="other_info">
											<div class="panel_left">
												<div class="container_image"><img src="'.rute__folder.$data["picture_"].'" alt="" class="image_user"></div>
												<div class="info_user_tutorial">
													<p class="name_user">'.$data["name_user"].'</p>
													<p class="time_tutorial">'.$this->get_format_date($data["date_tutorial"]).'</p>
												</div>
											</div>
											<div class="panel_right">
												<div class="like_counter">
													<i class="icon-favorite-heart-button"></i>
													<p class="count_">'.$data["count_likes"].'</p>
												</div>
											</div>
										</div>
									</div>
								</div>
								</a>';
						
					}	
			}else{
				echo "empty";
			}
			
		}


	}

	public function view_current_tutorial($id){
		$stmt = $this->con->prepare('SELECT tu.id_tutorials,tu.image_main,tu.title_,tu.info_tutorial,tu.tags_,tu.date_tutorial, us.name_user, us.picture_, COUNT(lk.id_tutorial) as count_likes FROM t_tutorials tu INNER JOIN u_users us  ON us.id_user = tu.id_user_post LEFT JOIN likes_tutorial lk ON tu.id_tutorials = lk.id_tutorial WHERE tu.id_tutorials = :id GROUP BY tu.id_tutorials HAVING COUNT(lk.id_tutorial) >= 0');
		$stmt->bindParam(':id',$id,\PDO::PARAM_INT);
		$stmt->execute();

		if($stmt){
			if($stmt->rowCount() > 0){
				return $stmt->fetch();
 			}else{
 				echo "empty";
 			}
		}
	}

	public function create_discussion($title_,$file,$id_user){
		$stmt = $this->con->prepare("INSERT INTO f_foro_ VALUES(NULL,:title_,:t_info_file,:id_user,:date_discussion)");
		$title =  $this->removeQuotation($this->con->proteccion($title_));
		$date_discussion =  date('d/m/y G:i:d');
		$stmt->bindParam(':title_',$title,\PDO::PARAM_STR);
		$stmt->bindParam(':t_info_file',$file,\PDO::PARAM_STR);
		$stmt->bindParam(':id_user',$id_user,\PDO::PARAM_INT);
		$stmt->bindParam(':date_discussion',$date_discussion,\PDO::PARAM_STR);
		$stmt->execute();

	
		if($stmt){
			echo "success";
		}else{
			echo "failed";
		}

	}


	public function get_current_discussion($id_question){
		$stmt = $this->con->prepare('SELECT forum.f_id_foro,forum.f_title_foro,forum.t_info_foro,forum.tags_,forum.date_post,us.name_user,us.picture_ FROM f_foro_ forum INNER JOIN u_users us ON us.id_user = forum.id_user WHERE forum.f_id_foro = :id_foro');
		$stmt->bindParam(':id_foro',$id_question,\PDO::PARAM_INT);
		$stmt->execute();


		if($stmt){
			if($stmt->rowCount() > 0){
				$data = $stmt->fetch();

				$response =  array('title' =>  $data['f_title_foro'],
									'file' => $data['t_info_foro'],
									'picture_user' => $data['picture_'],
									'name_user' => $data['name_user'],
									'tags_' => $data['tags_'],
									'id_foro' => $data['f_id_foro'] 
									);

				return $response;
			}else{
				echo "no existing discussion";
			}
		}else{
			echo "error consulting";
		}
	}

	public function create_response_d($file,$id_user,$id_question){
		$stmt = $this->con->prepare('INSERT INTO c_comment_foro VALUES(NULL,:file_,:id_foro,:id_user,:date_post)');
		$date_response =  date('d/m/y G:i:d');
		$stmt->bindParam(':file_',$file,\PDO::PARAM_STR);
		$stmt->bindParam(':id_foro',$id_question,\PDO::PARAM_INT);
		$stmt->bindParam(':id_user',$id_user,\PDO::PARAM_INT);
		$stmt->bindParam(':date_post',$date_response,\PDO::PARAM_INT);
		$stmt->execute();

		echo $file."\n".$id_user."\n".$id_question."\n".$date_response;

		if($stmt){
			echo "success";
		}else{
			echo "failed";
		}


	}


	public function get_this_response_comment($id_question,$id_comment){
		$stmt = $this->con->prepare("SELECT usr.name_user as user_response,usr.picture_ as picture_user_r,com.id_comment_foro,res.file_response_c as file_response FROM c_comment_foro com LEFT JOIN response_comment_ res ON res.id_comment_ = com.id_comment_foro INNER JOIN u_users usr ON usr.id_user = res.id_user_response_c WHERE com.id_foro = :id_question AND com.id_comment_foro = :id_comment");

		$stmt->bindParam(':id_question',$id_question,\PDO::PARAM_INT);
		$stmt->bindParam(':id_comment',$id_comment,\PDO::PARAM_INT);
		$stmt->execute();

		if($stmt){
			
			if($stmt->rowCount() > 0){
				$file = "";
				$dom = "";

				while($response = $stmt->fetch()){

					if(!empty($response['file_response'])){
						$file = file($response['file_response']);
					}else{
						$file = "empty";
					}

					
					if($file == "empty"){
						$dom = "";
					}else{
						foreach ($file as $callback) {

								$dom .= '<div class="content_comment_">
							<div class="question_ response_q">
								<div class="panel_head">
									<div class="container_image">
										<img src="https://cdn-images-1.medium.com/fit/c/120/120/1*RjtxJVETiqFVHZiHkjuOKg.png" alt="" class="image_user">
									</div>
									<div class="info_user">
										<a href="#" class="name_user">Jhon Murillo Mendez</a>
										<p class="time_question p_time_question">Hace 1 semana</p>
									</div>
								</div>
								<div class="panel_body">
									<p class="text_info_normal">'.$callback.'</p>
									<div class="controls_question">
										<div class="container_button">
											<div class="input_button"><button class="btn_action"><i class="icon-like"></i> <p class="count_val">0</p></button></div>
											<div class="input_button"><button class="btn_action btn_rotate"><i class="icon-like"></i> <p class="count_val">0</p></button></div>
											
										</div>
									</div>
								</div>
							</div>
							
						</div>';
					 }

						
					}
					
				}

				return $dom;
			}else{
				echo "sss";
			}
		}else{
			echo "failed";
		}
	}

	public function get_a_response_c_($id_question){
		$stmt = $this->con->prepare('SELECT us.name_user,us.picture_,com.id_comment_foro,com.info_comment,com.date_response_,res.file_response_c,res.date_response_c,usr.name_user as name_user_response,usr.picture_ as picture_usr_response FROM c_comment_foro com INNER JOIN u_users us ON us.id_user = com.id_user_comment LEFT JOIN response_comment_ res ON res.id_comment_ = com.id_comment_foro INNER JOIN u_users usr ON usr.id_user = res.id_user_response_c WHERE com.id_foro = :id_question');
		$stmt->bindParam(':id_question',$id_question,\PDO::PARAM_INT);
		$stmt->execute();

		if($stmt){
			if($stmt->rowCount() > 0){
				$dom = "";
				$file_ = "";
				while($response = $stmt->fetch()){
					$file = file($response['info_comment']);
					if(!empty($response['file_response_c'])){
						$file_ = file($response['file_response_c']);

					}else{
						$file_ = "empty";
					}

					if($file_ == "empty"){
							$dom = "";
					}else{
							foreach ($file_ as $callback) {
								$dom = '<div class="content_comment_">
							<div class="question_">
								<div class="panel_head">
									<div class="container_image">
										<img src="https://cdn-images-1.medium.com/fit/c/120/120/1*RjtxJVETiqFVHZiHkjuOKg.png" alt="" class="image_user">
									</div>
									<div class="info_user">
										<a href="#" class="name_user">Jhon Murillo Mendez</a>
										<p class="time_question p_time_question">Hace 1 semana</p>
									</div>
								</div>
								<div class="panel_body">
									<p class="text_info_normal">'.$callback.'</p>
									<div class="controls_question">
										<div class="container_button">
											<div class="input_button"><button class="btn_action"><i class="icon-like"></i> <p class="count_val">0</p></button></div>
											<div class="input_button"><button class="btn_action btn_rotate"><i class="icon-like"></i> <p class="count_val">0</p></button></div>
											
										</div>
									</div>
								</div>
							</div>
							
						</div>';
							}
					}
					$c = explode(" ", $response['name_user']);
					foreach ($file as  $value) {
							echo '<div class="question_">
						<div class="panel_head">
							<div class="container_image">
								<img src="'.rute__folder.$response["picture_"].'"" class="image_user">
							</div>
							<div class="info_user">
								<a href="#" class="name_user">'.$response["name_user"].'</a>
								<p class="time_question p_time_question">Hace 1 semana</p>
							</div>
						</div>
						<div class="panel_body">
							'.$value.'
							<div class="controls_question">
								<div class="container_button">
									<div class="input_button"><button type="button" class="btn_action"><i class="icon-like"></i> <p class="count_val">0</p></button></div>
									<div class="input_button"><button type="button" class="btn_action btn_rotate"><i class="icon-like"></i> <p class="count_val">0</p></button></div>
									<div class="input_button input_reply"><button type="button" class="btn_action btn_reply"><i class="icon-reply"></i> Responderle a '.$c[0].'</button></div>
								</div>
							</div>
						</div>
						<div class="box_send_question send_comment" style="position:relative;top:-12px;display:none;" data-comment="'.$response["id_comment_foro"].'">
							<div class="box_">
								<div class="panel_left_box" style="width:95%;margin:auto;">
									<div class="container_image">
										<img src="https://cdn-images-1.medium.com/fit/c/120/120/1*RjtxJVETiqFVHZiHkjuOKg.png" alt="" class="image_user">
									</div>
									<a href="#" class="name_user">Code tutoriales</a>
								</div>
								<div class="panel_right_box">
									<div class="input_group input_textarea_">
										<textarea name="" id="" cols="30" rows="10" class="textfield field_response_c" placeholder="Realiza una pregunta ..."></textarea>
									</div>
									<div class="input_group" style="margin:auto;width:85%;">
										<div class="container_button" style="position:relative; left:10px;">
											<div class="input_button" style="top:12px;"><button class="button_ btn_green btn_post_response">Publicar</button></div>
											<div class="input_button"  style="top:12px;"><button class="button_ btn_cancel">Cancelar</button>
										</div>
									</div>
									</div>
								</div>
							</div>
						</div>
						'.$dom.'
					</div>';
					}

				}
			}
		}
		 
	}

	

	public function get_all_response_current_discussion($id_question){
		
		$stmt = $this->con->prepare("SELECT us.name_user,us.picture_,com.id_comment_foro,com.info_comment,com.date_response_ as file_response,COUNT(lk.forum_comment_id) as count_likes FROM c_comment_foro com INNER JOIN u_users us ON us.id_user = com.id_user_comment LEFT JOIN l_like_foro lk ON lk.forum_comment_id = com.id_comment_foro WHERE com.id_foro = :id_question GROUP BY com.id_comment_foro HAVING COUNT(lk.forum_comment_id) >= 0");
		$stmt->bindParam(':id_question',$id_question,\PDO::PARAM_INT);
		$stmt->execute();

		if($stmt){
			if($stmt->rowCount() > 0){
				$file = "";
				$file_ = "";
				$dom = "";
				$count = 0;
				
				
				
				while ($data = $stmt->fetch()) {
					
						$file = file($data['info_comment']);
						$c = explode(" ", $data["name_user"]);
					
					foreach($file as $value) {	
						echo '<div class="question_">
						<div class="panel_head">
							<div class="container_image">
								<img src="'.rute__folder.$data["picture_"].'"" class="image_user">
							</div>
							<div class="info_user">
								<a href="#" class="name_user">'.$data["name_user"].'</a>
								<p class="time_question p_time_question">Hace 1 semana</p>
							</div>
						</div>
						<div class="panel_body">
							'.$value.'
							<div class="controls_question">
								<div class="container_button">
									<div class="input_button"><button type="button" class="btn_action"><i class="icon-like"></i> <p class="count_val">'.$data["count_likes"].'</p></button></div>
									<div class="input_button"><button type="button" class="btn_action btn_rotate"><i class="icon-like"></i> <p class="count_val">0</p></button></div>
									<div class="input_button input_reply"><button type="button" class="btn_action btn_reply"><i class="icon-reply"></i> Responderle a '.$c[0].'</button></div>
								</div>
							</div>
						</div>
						<div class="box_send_question send_comment" style="position:relative;top:-12px;display:none;" data-comment="'.$data["id_comment_foro"].'">
							<div class="box_">
								<div class="panel_left_box" style="width:95%;margin:auto;">
									<div class="container_image">
										<img src="https://cdn-images-1.medium.com/fit/c/120/120/1*RjtxJVETiqFVHZiHkjuOKg.png" alt="" class="image_user">
									</div>
									<a href="#" class="name_user">Code tutoriales</a>
								</div>
								<div class="panel_right_box">
									<div class="input_group input_textarea_">
										<textarea name="" id="" cols="30" rows="10" class="textfield field_response_c" placeholder="Realiza una pregunta ..."></textarea>
									</div>
									<div class="input_group" style="margin:auto;width:85%;">
										<div class="container_button" style="position:relative; left:10px;">
											<div class="input_button" style="top:12px;"><div class="btn_loader btn_loader_green"><div class="circle_loader" style="position: relative;top:3px;"><div class="loader"></div></div><button class="button_ btn_green btn_post_response">Publicar</button></div>
											<div class="input_button"  style="top:12px;"><button class="button_ btn_cancel">Cancelar</button>
										</div>
									</div>
									</div>
								</div>
							</div>
						</div>
						'.$this->get_this_response_comment($id_question,$data['id_comment_foro']).'
					</div>';

				}
						
					
					
				}
			}else{
				echo "this question not there response";
			}
		}
	}

	public function get_major_format_date($string){
		$date_ = substr($string, 0,strpos($string, " "));
		$array_meses = array('Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre');

		return explode("/", $date_)[0]." de ".$array_meses[str_replace('0','', explode("/", $date_)[1])]." de ". explode("/", $date_)[2];

	}

	public function dar_respuestas_foro_actual($id_pregunta){
		$stmt = $this->con->prepare("SELECT usuario_comentario_padre,picture_usuario_comentario,id_comentario_padre,comentario_padre,fecha_comentario_padre,
usuario_res,picture_user_res,comentario_hijo,fecha_comentario_hijo
FROM
(
SELECT us.name_user as usuario_comentario_padre, us.picture_ as picture_usuario_comentario, com.id_comment_foro as id_comentario_padre, com.info_comment as comentario_padre, com.date_response_ as fecha_comentario_padre,'' as usuario_res,'' as picture_user_res, '' as comentario_hijo, '' as Fecha_comentario_hijo FROM c_comment_foro com
LEFT JOIN response_comment_ res ON res.id_comment_ = com.id_comment_foro
INNER JOIN u_users us ON us.id_user = com.id_user_comment
UNION ALL
SELECT '' as usuario_comentario_padre, '' as picture_usuario_comentario,com.id_comment_foro as id_comentario_padre, '' as comentario_padre, '' as fecha_comentario_padre,
    us.name_user as usuario_res, us.picture_ as picture_user_res, file_response_c as comentario_hijo, res.date_response_c as Fecha_comentario_hijo FROM c_comment_foro com
LEFT JOIN response_comment_ res ON res.id_comment_ = com.id_comment_foro
INNER JOIN u_users us ON us.id_user = res.id_user_response_c
) AS comentario
GROUP BY id_comentario_padre,comentario_padre,fecha_comentario_padre,comentario_hijo,fecha_comentario_hijo
ORDER BY id_comentario_padre,fecha_comentario_hijo,fecha_comentario_padre ASC");
		
		$stmt->execute();

		if($stmt){
			if($stmt->rowCount() > 0){
				 $id_comentario=0; // inicializo el ID vigente

				    while($data = $stmt->fetch()){
				      $new_id = $data['id_comentario_padre'];
					      /*if($new_id != $id_comentario) {*/ // si no es el mismo comentario
					         $id_comentario = $new_id; // actualizo el ID vigente
					         	$archivo = $data['comentario_padre'];
					         	
					         	if($archivo != null && $data['comentario_hijo'] == null){
					         		$file = file($archivo);
					         		foreach ($file as $comentarios) {
					        			echo '<div class="question_">
						<div class="panel_head">
							<div class="container_image">
								<img src="'.rute__folder.$data["picture_usuario_comentario"].'" class="image_user">
							</div>
							<div class="info_user">
								<a href="#" class="name_user">'.$data["usuario_comentario_padre"].'</a>
								<p class="time_question p_time_question">Publicado el '.$this->get_major_format_date($data["fecha_comentario_padre"]).'</p>
							</div>
						</div>
						<div class="panel_body">
							'.$comentarios.'
							<div class="controls_question">
								<div class="container_button">
									<div class="input_button"><button type="button" class="btn_action"><i class="icon-like"></i> <p class="count_val">0</p></button></div>
									<div class="input_button"><button type="button" class="btn_action btn_rotate"><i class="icon-like"></i> <p class="count_val">0</p></button></div>
									<div class="input_button input_reply"><button type="button" class="btn_action btn_reply"><i class="icon-reply"></i> Responderle a </button></div>
								</div>
							</div>
						</div>
						<div class="box_send_question send_comment" style="position:relative;top:-12px;display:none;" data-comment="'.$data["id_comentario_padre"].'">
							<div class="box_">
								<div class="panel_left_box" style="width:95%;margin:auto;">
									<div class="container_image">
										<img src="https://cdn-images-1.medium.com/fit/c/120/120/1*RjtxJVETiqFVHZiHkjuOKg.png" alt="" class="image_user">
									</div>
									<a href="#" class="name_user">Code tutoriales</a>
								</div>
								<div class="panel_right_box">
									<div class="input_group input_textarea_">
										<textarea name="" id="" cols="30" rows="10" class="textfield field_response_c" placeholder="Realiza una pregunta ..."></textarea>
									</div>
									<div class="input_group" style="margin:auto;width:85%;">
										<div class="container_button" style="position:relative; left:10px;">
											<div class="input_button" style="top:12px;"><div class="btn_loader btn_loader_green"><div class="circle_loader" style="position: relative;top:3px;"><div class="loader"></div></div>
										</div><button class="button_ btn_green btn_post_response">Publicar</button></div>
											<div class="input_button"  style="top:12px;"><button class="button_ btn_cancel">Cancelar</button>
										</div>
									</div>
									</div>
								</div>
							</div>
						</div>
						
					</div>';
					        		}
					         	}
					        	
					      //}

					      $r_comentarios = $data['comentario_hijo'];
					      if($r_comentarios != null){
					      		$f_file = file($r_comentarios);
					         	foreach ($f_file as $respuestas_) {
					         		 echo '<div class="content_comment_">
							<div class="question_ question_responses">
								<div class="panel_head">
									<div class="container_image">
										<img src="'.rute__folder.$data["picture_user_res"].'" alt="" class="image_user">
									</div>
									<div class="info_user">
										<a href="#" class="name_user">'.$data["usuario_res"].'</a>
										<p class="time_question p_time_question">'.$this->get_major_format_date($data["fecha_comentario_hijo"]).'</p>
									</div>
								</div>
								<div class="panel_body">
									<p class="text_info_normal text_comment_responses">'.$respuestas_.'</p>
									<div class="controls_question">
										<div class="container_button">
											<div class="input_button"><button class="btn_action"><i class="icon-like"></i> <p class="count_val">0</p></button></div>
											<div class="input_button"><button class="btn_action btn_rotate"><i class="icon-like"></i> <p class="count_val">0</p></button></div>
											
										</div>
									</div>
								</div>
							</div>
							
						</div>';
					         	}
					        }
				        
				        
				        
				   }
			}else{
				echo "Este foro no tiene comentarios";
			}
		}else{
			echo "error";
		}
	}

	public function add_response_comment($comment,$id_user,$file){
		$stmt = $this->con->prepare('INSERT INTO response_comment_ VALUES(NULL,:id_comment,:id_user_response_c,:file_,:date_response_c)');
		$date_response_c =  date('d/m/y G:i:d');
		$stmt->bindParam(':id_comment',$comment,\PDO::PARAM_INT);
		$stmt->bindParam(':id_user_response_c',$id_user,\PDO::PARAM_INT);
		$stmt->bindParam(':file_',$file,\PDO::PARAM_STR);
		$stmt->bindParam(':date_response_c',$date_response_c,\PDO::PARAM_STR);
		$stmt->execute();

		
		if($stmt){
			echo "success";
		}else{
			echo "error";
		}

	}
}



 ?>