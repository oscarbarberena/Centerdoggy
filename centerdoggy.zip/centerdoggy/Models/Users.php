<?php namespace Models;

class Users{
	


	private $id;
	private $code;
	private $name;
	private $email;
	private $sex;
	private $password;
	private $picture;
	private $status;
	private $type_user;
	private $city;
	private $neit;

	private $conn;

	public function __construct(){
		$this->conn = new Connection();
	}

	public function set($attr,$value){
		$this->$attr = $value;
	}


	public function get($attr){
		return $this->attr;
	}

	public function list($param){

		$stmt = "";

		if($param == "nothing"){
			$sql = 'SELECT * FROM users';
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			
		}else if($param == "lenders"){
			$sql = 'SELECT * FROM lenders WHERE id_lender =:id_lender';
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':id_lender',$this->id,\PDO::PARAM_INT);
			$stmt->execute();

			if($stmt){
				if($stmt->rowCount() > 0){
					
				}else{
					$sql = 'SELECT * FROM owners WHERE id_owner =:id_owner';
					$stmt = $this->conn->prepare($sql);
					$stmt->bindParam(':id_owner',$this->id,\PDO::PARAM_INT);
					$stmt->execute();
				}	
			}

			
			
		}else if($param == "owners"){
			$sql = 'SELECT * FROM owners WHERE id_owner =:id_owner';
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':id_owner',$this->id,\PDO::PARAM_INT);
			$stmt->execute();

			if($stmt){
				if($stmt->rowCount() > 0){
				
				}else{
					$sql = 'SELECT * FROM lenders WHERE id_lender =:id_lender';
					$stmt = $this->conn->prepare($sql);
					$stmt->bindParam(':id_lender',$this->id,\PDO::PARAM_INT);
					$stmt->execute();
				}
			}
			
		}else{
			$sql = 'SELECT * FROM users WHERE id_user =:id';
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':id',$this->id,\PDO::PARAM_INT);
			$stmt->execute();
			
		}
		
		return $stmt;
	}


	public function add(){

		$sql = 'INSERT INTO users VALUES(NULL,:name_user,:email,:password,:status,:picture,:type_user)';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':name_user',$this->conn->proteccion($this->name),\PDO::PARAMT_STR);
		$stmt->bindParam(':email',$this->conn->proteccion($this->email),\PDO::PARAMT_STR);
		$stmt->bindParam(':password',$this->conn->proteccion($this->password),\PDO::PARAMT_STR);
		$stmt->bindParam(':status',$this->conn->proteccion($this->status),\PDO::PARAMT_STR);
		$stmt->bindParam(':picture',$this->conn->proteccion($this->picture),\PDO::PARAMT_STR);
		$stmt->bindParam(':type_user',$this->type_user,\PDO::PARAMT_INT);
		$stmt->execute();

		return $stmt;
	}

	public function edit(){

		$sql = 'UPDATE FROM users SET nombre =:name WHERE id_user =:id';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':name',$this->conn->proteccion($this->name),\PDO::PARAMT_STR);
		$stmt->bindParam(':id',$this->id,\PDO::PARAMT_INT);
		$stmt->execute();

		return $stmt;

	}

	public function delete(){
		$sql = 'DELETE FROM users WHERE id_user =:id';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':id',$this->id,\PDO::PARAMT_INT);
		$stmt->execute();

		return $stmt;

	}

	public function signin(){
		$sql = 'SELECT * FROM users WHERE email =:email AND password =:pass';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':email',$this->email,\PDO::PARAM_STR);
		$stmt->bindParam(':pass',$this->password,\PDO::PARAM_STR);
		$stmt->execute();

		return $stmt;

	}

	public function loginowners(){
		$sql = 'SELECT * FROM owners WHERE email =:email AND password =:pass';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':email',$this->email,\PDO::PARAM_STR);
		$stmt->bindParam(':pass',$this->password,\PDO::PARAM_STR);
		$stmt->execute();

		return $stmt;		
	}

	public function loginlenders(){
		$sql = 'SELECT * FROM lenders WHERE email =:email AND password =:pass';
		$stmt = $this->conn->prepare($sql);
		$stmt->bindParam(':email',$this->email,\PDO::PARAM_STR);
		$stmt->bindParam(':pass',$this->password,\PDO::PARAM_STR);
		$stmt->execute();

		return $stmt;		
	}


	public function search_for_name(){

		$sql = 'SELECT id_owner,name_owner FROM owners WHERE name_owner LIKE :name';
		$stmt = $this->conn->prepare($sql);
		$filter = '%'.$this->name.'%';
		$stmt->bindParam(':name',$filter,\PDO::PARAM_STR);
		$stmt->execute();

		return $stmt;
	}

	



	
}

 ?>