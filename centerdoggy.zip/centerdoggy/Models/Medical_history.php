<?php namespace Models;

class Medical_history{

	private $id;
	private $id_pet;
	private $id_vet;
	private $name_v;
	private $sex_v;
	private $telefono_v;
	private $city_v;
	private $direccion_v;
	private $email_v;
	private $whatsapp_v;
	private $conexion;
	private $servicio_salud = 'N';
	private $certificado_v;
	private $hemograma;
	private $hemoparasito;
	private $control_veterinario = 'N';
	private $en_consultorio = 'N';
	private $domiciliaria = 'N';
	private $consulta_ingreso = 'N';
	private $plan_mantenimiento = 'N';
	private $afiliacion_eps = 'N';

	public function __construct(){
		$this->conexion = new Connection();
	}

	public function set($attr,$value){
		$this->$attr = $value;
	}

	public function add(){

		$sql = 'INSERT INTO medical_history VALUES(NULL,:id_pet,:id_vet,:name_v,:sex_v,:telefono_v,:city_v,:direccion_v,:email_v,:whatsapp_v,:servicio_salud,:certificado_v,:hemo,:hemop,:control_v,:en_consultorio,:domiciliaria,:consulta_ingreso,:plan_mantenimiento,:afiliacion_eps)';

	
		$id_vet = 2;
		$stmt = $this->conexion->prepare($sql);
		$stmt->bindParam(':id_pet',$this->id_pet,\PDO::PARAM_INT);
		$stmt->bindParam(':id_vet',$id_vet,\PDO::PARAM_INT);
		$stmt->bindParam(':name_v',$this->name_v,\PDO::PARAM_STR);
		$stmt->bindParam(':sex_v',$this->sex_v,\PDO::PARAM_STR);
		$stmt->bindParam(':telefono_v',$this->telefono_v,\PDO::PARAM_INT);
		$stmt->bindParam(':city_v',$this->city_v,\PDO::PARAM_STR);
		$stmt->bindParam(':direccion_v',$this->direccion_v,\PDO::PARAM_STR);
		$stmt->bindParam(':email_v',$this->email_v,\PDO::PARAM_STR);
		$stmt->bindParam(':whatsapp_v',$this->whatsapp_v,\PDO::PARAM_INT);
		$stmt->bindParam(':servicio_salud',$this->servicio_salud,\PDO::PARAM_STR);
		$stmt->bindParam(':certificado_v',$this->certificado_v,\PDO::PARAM_STR);
		$stmt->bindParam(':hemo',$this->hemograma,\PDO::PARAM_STR);
		$stmt->bindParam(':hemop',$this->hemoparasito,\PDO::PARAM_STR);
		$stmt->bindParam(':control_v',$this->control_veterinario,\PDO::PARAM_STR);
		$stmt->bindParam(':control_v',$this->control_veterinario,\PDO::PARAM_STR);
		$stmt->bindParam(':en_consultorio',$this->en_consultorio,\PDO::PARAM_STR);
		$stmt->bindParam(':domiciliaria',$this->domiciliaria,\PDO::PARAM_STR);
		$stmt->bindParam(':consulta_ingreso',$this->consulta_ingreso,\PDO::PARAM_STR);
		$stmt->bindParam(':plan_mantenimiento',$this->plan_mantenimiento,\PDO::PARAM_STR);
		$stmt->bindParam(':afiliacion_eps',$this->afiliacion_eps,\PDO::PARAM_STR);
		$stmt->execute();


		return $stmt;
		
	}


	// public function get_info_v_mh(){
	// 	$sql = 'SELECT * FROM veterinarians WHERE '
	// }

	public function list_data(){

		$sql = 'SELECT p.name_pet,p.picture,mh.name_v,mh.sex_v,mh.telefono_v,mh.city_v,mh.direccion_v,mh.email_v,mh.whatsapp,mh.Certificado_vacunacion,mh.Hemograma,mh.Hemoparasitos FROM medical_history as mh INNER JOIN pets as p ON mh.id_pet = p.id_pet  WHERE mh.id_pet =:id_';
		$stmt = $this->conexion->prepare($sql);
		$stmt->bindParam(':id_',$this->id_pet,\PDO::PARAM_INT);
		$stmt->execute();

		if($stmt){
			$data = "";
			if($stmt->rowCount() > 0){
				$data = $stmt->fetch();

				return $data;
			}else{
				$sql = 'SELECT * FROM pets WHERE id_pet =:id_';
				$stmt = $this->conexion->prepare($sql);
				$stmt->bindParam(':id_',$this->id_pet,\PDO::PARAM_INT);
				$stmt->execute();
				//echo "hola ".$stmt->fetch()['picture'];
				$data = $stmt->fetch();

				return $data = array(
					'name_v' => '',
					'sex_v' => '',
					'direccion_v' => '',
					'telefono_v' => '',
					'city_v' => '',
					'email_v' => '',
					'whatsapp' => '',
					'name_pet' => $data['name_pet'],
					'image' => $data['picture']
				);


			}
		}
		

	}


	public function getinfo_(){

		return array('name_pet' => 'Albeiro', 'picture' => 'ninguna.jpg');
	}


	public function update_add(){

		$sql  = 'UPDATE medical_history SET Servicio_salud = :s_s,Certificado_vacunación =:cv,Hemograma =:hemo, Hemoparasitos =:hemop, Consulta_de_ingreso =:cin,Afiliaciòn_EPS = :aps';
		$stmt = $this->conexion->prepare($sql);
		$stmt->bindParam(':s_s',$this->servicio_salud,\PDO::PARAM_INT);
		$stmt->bindParam(':cv',$this->certificado_v,\PDO::PARAM_STR);
		$stmt->bindParam(':hemo',$this->hemograma,\PDO::PARAM_STR);
		$stmt->bindParam(':hemop',$this->hemoparasito,\PDO::PARAM_STR);
		$stmt->bindParam(':cin',$this->consulta_ingreso,\PDO::PARAM_STR);
		$stmt->bindParam(':aps',$this->afiliacion_eps,\PDO::PARAM_STR);
		$stmt->execute();
		

		return $stmt;

	}
}



 ?>