<?php namespace Models;


class Services{

	private $conexion;


	public function __construct(){
		$this->conexion = new Connection();
	}


	public function list($type){
		
		if($type == "adomicilio"){

			$sql = 'SELECT * FROM home_service';
			$stmt = $this->conexion->prepare($sql);
			$stmt->execute();
			return $stmt;
		}else{

			$sql = 'SELECT * FROM service_consultorio';
			$stmt = $this->conexion->prepare($sql);
			$stmt->execute();
			return $stmt;
		}
	}
}



 ?>