<?php

require("Config/Request.php");
require("Config/Router.php");
require("Config/Loading.php");
define('SPACE',DIRECTORY_SEPARATOR);
define('path',realpath(dirname(__FILE__)) . SPACE);
define('rute',"Views/");
define('rute__folder',"http://localhost:8089/centerdoggy/Views/");
Config\Loading::run();
Config\Router::run(new Config\Request());


 ?>
