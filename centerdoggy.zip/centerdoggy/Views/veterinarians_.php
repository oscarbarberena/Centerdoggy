<?php 
session_start();

// if(isset($_SESSION['email']) || isset($_SESSION['id_user'])){
// 	//$info = $this->getinfo($_SESSION['id_user'],"owners");
// }else{
// 	header('Location: http://localhost:8089/centerdoggy/signin/');
// }


 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
	<a href="/centerdoggy/portal_owner/" class="logo_icono" style="position:absolute;left:15px;top:10px;z-index: 200;">
		<h1 class="name_company">PET_CENTER</h1>
	</a>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section c_green">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">reservas</a></li>
			<li class="list_"><a href="signin.html" class="link_section btn_option_user">Mi perfil</a><div class="sub_options_">
                <div class="list_option">
                    <a href="/centerdoggy/profile/<?php echo $_SESSION['id_user']; ?>/" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/my_pets/" class="link_">Mis mascotas</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/signout/close_sesion/<?php echo $_SESSION['id_user'];?>" class="link_">Salir</a>
                </div>
            </div></li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
		<div class="content_info pane_section">
			<div class="content_title center p-x30 m_bottomx60">
				<h2 class="title_ t_green">Estos son los Veterinarios registradas en nuestro portal</h2>
				<p class="info_">Selecciona el veterinario de tu interes!</p>
			</div>
			<div class="container_search">
				<div class="input_group">
					<input type="text" name="" id="" class="textfield" placeholder="Busca a un veterinario...">
				</div>
				<div class="input_button">
					<button type="button" class="button_ b_green">Buscar</button>
				</div>
			</div>
			<div class="content_box flex wrap" id="content_veterinarians" style="justify-content: center;"></div>
		</div>
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>
		

		fetch('/centerdoggy/veterinarians_/list/',{
			method:'POST'	
		})
		.then(response => {
				return response.json();
		})
		.then(result => {
			if(result.hasOwnProperty("data")){
				if(result.data == "empty"){
					console.log('No hay datos');
					document.getElementById('content_veterinarians').innerHTML = '<div style="display:block; padding:25px;"><p>Aun no has registrado tu o tus mascotas</p></div>';
				}
			}else{
				console.log(result);
				var dom = "";
				 result.map((item,index) => {
				 		dom += `<a href="/centerdoggy/veterinarians_/view/${result[index].id_vet}" class="box_ b_mtx30">
					<div class="box_info  box_service">
						<div class="panel_head">
							<div class="container_image_">
								<img src="http://localhost:8089/centerdoggy/Views/${result[index].picture_}" alt="" class="image_avatar">
							</div>
						</div>
						<div class="panel_body">
							<p class="name_">${result[index].nombre_completo}</p>
							<p class="description_short">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Numquam, assumenda.</p>
						</div>
					</div>
				</a>`;
				 });	
					
				document.getElementById('content_veterinarians').innerHTML = dom;
			}


				
		});

		
		

		
		

	</script>
</body>
</html>
