<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon/style.css">
</head>
<header class="main_header">
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section">Nuestros servicios</a></li>
			<li class="list_"><a href="#" class="link_section">Como funciona</a></li>
			<li class="list_"><div class="input_button"><a href="signin.html" class=" button_ b_green">Iniciar Sesión</a></div></li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_" style="height:auto;">
		<div class="content_info" style="margin-bottom: 5px;">
			<div class="content_title center">
				<h2 class="title_ t_green">Selecciona la tus horas laborales</h2>
				<p class="info_">De acuerdo a los diás que escojistes, debes asignarle un horario laboral</p>
			</div>
			
		</div>
		<div class="content_info"  style="height:620px; padding-bottom: 10px;">
			
			<div class="container_time">
				<div class="input_group">
					<label for="" class="lb_info">Dias de la semana</label>
					<input type="text" name="" id="field_starttime" class="textfield field_choose_sc field_day" data-id="1" placeholder="Selecciona tus días laborales" readonly="On" style="cursor:pointer;">
					<div class="sub_options_ sub_controls_ sub_extends">
		                <?php $this->list_days_work_lender(); ?>
            		</div>
				</div>
				<div class="input_group" style="width: 190px;">
					<label for="" class="lb_info">Desde</label>
					<input type="time"  name="" id="field_endtime" class="textfield  start_time" data-id="0" placeholder="0:00">
					
				</div>
				<div class="input_group" style="width: 190px;">
					<label for="" class="lb_info">Hasta</label>
					<input type="time"  name="" id="field_endtime" class="textfield  end_time" data-id="0" placeholder="0:00">
					
				</div>
			</div>
			<div class="input_group w-x70" style="margin:auto; left: -5px;">
				<div class="input_button" style="display: block;">
					<button type="submit" class="button_ b_green btn_send_">Continuar</button>
				</div>
			</div>
		</div>
		<div class="form_loader">
	         <div class="container_loader">
	               <div class="bar_loader">
	               <div class="loader"></div>
	                <img src="<?php echo rute__folder;?>img/padlock.svg" alt="">
	          </div>
	            <p class="info_">Estamos registrandote...</p>
	          </div>
        </div>
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>

		var item = "",
			numstart = "",
			numend = "";

		function getParameterByName(name){
		    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
		    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
		    results = regex.exec(location.search);
		    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
		}

		var showSubmenu = function(){
			
			this.parentNode.children[2].style.display = 'block';
		};

		var hideSubmenu = function(e){
			e.preventDefault();
			
			
			item = this;
			this.parentNode.parentNode.parentNode.children[1].value = this.innerText;
			this.parentNode.parentNode.parentNode.children[1].dataset.id = this.dataset.day;
			this.parentNode.parentNode.style.display = 'none';
			console.log(this.parentNode.parentNode.parentNode.children[1]);
		};

		var hideSubmenu_ = function(e){
			e.preventDefault();
			this.parentNode.parentNode.parentNode.children[1].value = this.innerText;
			this.parentNode.parentNode.parentNode.children[1].dataset.id = this.dataset.hour;
			this.parentNode.parentNode.style.display = 'none';
		};

		[].forEach.call(document.querySelectorAll('.field_choose_sc'),fields => {
			// statements
			fields.addEventListener('focus', showSubmenu);
			
		});

		[].forEach.call(document.querySelectorAll('.days_choosed'), btn_days => {
			// statements
			btn_days.addEventListener('click',hideSubmenu);
		});

		[].forEach.call(document.querySelectorAll('.range_days'), btn_range => {
			// statements
			btn_range.addEventListener('click',hideSubmenu_);
		});
		

		var get_range_hours = function(time){
			let numinit = 0;
			if(time == "6" || time == "7"){
				numinit = 1;
			}else if(time == "8"){
				numinit = 2;
			}else if(time == "9"){
				numinit = 3;
			}else if(time == "10"){
				numinit = 4;
			}else if(time == "11"){
				numinit = 5;
			}else if(time == "12"){
				numinit = 6;
			}else if(time == "13"){
				numinit = 7;
			}else if(time == "14"){
				numinit = 8;
			}else if(time == "15"){
				numinit = 9;
			}else if(time == "16"){
				numinit = 10;
			}else if(time == "17"){
				numinit = 11;
			}else if(time == "18"){
				numinit = 12;
			}else{
				numinit = 90
			}

			return numinit;
		};

		var choose_index = 0;
		document.querySelector('.btn_send_').addEventListener('click', e =>{
			e.preventDefault();
			days_choose = "";
				
			var month =  (parseInt(getParameterByName("month"))+1);
			//var month = 11;
			var dias  =  document.querySelector('.field_day').dataset.id;
			var start_time =	 document.querySelector('.start_time').value;
			var end_time =	 document.querySelector('.end_time').value;
			var id_lender = getParameterByName("id_lender"); 
			
			console.log(month);

			if(month == "" && dias == "" && start_time == "" && end_time == ""){
				alert('Datos incompletos');
			}else if(month == "" || month == null || month == "undefined" ){
				console.log('mes vacio');
			}else if(dias == ""){
				console.log('dias vacios');
			}else if(start_time == "" || start_time == 0){
				console.log('inicio de horas vacias');
			}else if(end_time == "" || end_time == 0){
				console.log('final de horas vacias');
			}else{
				numstart = parseInt(start_time.toString().replace(new RegExp(':00','g'),' '));
				numend   = parseInt(end_time.toString().replace(new RegExp(':00','g'),' '));
	
				
				
				
				/*if(typeof(document.querySelectorAll('.days_choosed')[(parseInt(item.dataset.index)+1)]) == "undefined"){
								item.parentNode.parentNode.parentNode.children[1].value  = document.querySelectorAll('.days_choosed')[(parseInt(item.dataset.index)-1)].innerText;
								item.parentNode.parentNode.parentNode.children[1].dataset.id = document.querySelectorAll('.days_choosed')[(parseInt(item.dataset.index)-1)].dataset.day;
								document.querySelectorAll('.days_choosed')[parseInt(item.dataset.index)].style.display = 'none';
								//document.querySelectorAll('.days_choosed')[parseInt(item.dataset.index)].remove();
								//window.location = response;
							}else{
								item.parentNode.parentNode.parentNode.children[1].value  = document.querySelectorAll('.days_choosed')[(parseInt(item.dataset.index)+1)].innerText;
								item.parentNode.parentNode.parentNode.children[1].dataset.id = document.querySelectorAll('.days_choosed')[(parseInt(item.dataset.index)+1)].dataset.day;
								document.querySelectorAll('.days_choosed')[parseInt(item.dataset.index)].style.display = 'none';
								//document.querySelectorAll('.days_choosed')[parseInt(item.dataset.index)].remove();
								console.log(document.querySelectorAll('.days_choosed')[(parseInt(item.dataset.index)+1)].dataset.day);

							}*/
				$.ajax({
					url:"/centerdoggy/calendar_lender/add_schedule_lender/",
					type:"POST",
					data:{id_lender:id_lender,field_day:dias,month:month, start_time:get_range_hours(numstart),end_time:get_range_hours(numend)},

					beforeSend: function(){
						$('.form_loader').css('visibility','visible');
					},

					complete: function(){
						$('.form_loader').css('visibility','hidden');
					},
					success: function(response){
						console.log(response);
						if(response == "failed"){

						}else{
							if(item==""){
					
					if((choose_index+1) == document.querySelectorAll('.days_choosed').length){
						if(typeof(document.querySelectorAll('.days_choosed')[(choose_index)]) != "undefined"){
						    document.querySelectorAll('.days_choosed')[choose_index].parentNode.parentNode.parentNode.children[1].value  = document.querySelectorAll('.days_choosed')[(parseInt(document.querySelectorAll('.days_choosed')[choose_index].dataset.index))].innerText;
						    document.querySelectorAll('.days_choosed')[choose_index].parentNode.parentNode.parentNode.children[1].dataset.id = document.querySelectorAll('.days_choosed')[(parseInt(document.querySelectorAll('.days_choosed')[choose_index].dataset.index))].dataset.day;
						    document.querySelectorAll('.days_choosed')[parseInt(document.querySelectorAll('.days_choosed')[choose_index].dataset.index)].style.display = 'none';
							
						}
						window.location = response;
					}else{
						if(typeof(document.querySelectorAll('.days_choosed')[(choose_index)]) != "undefined"){
						    document.querySelectorAll('.days_choosed')[choose_index].parentNode.parentNode.parentNode.children[1].value  = document.querySelectorAll('.days_choosed')[(parseInt(document.querySelectorAll('.days_choosed')[choose_index].dataset.index)+1)].innerText;
						    document.querySelectorAll('.days_choosed')[choose_index].parentNode.parentNode.parentNode.children[1].dataset.id = document.querySelectorAll('.days_choosed')[(parseInt(document.querySelectorAll('.days_choosed')[choose_index].dataset.index)+1)].dataset.day;
						    document.querySelectorAll('.days_choosed')[parseInt(document.querySelectorAll('.days_choosed')[choose_index].dataset.index)].style.display = 'none';
							console.log(document.querySelectorAll('.days_choosed')[(parseInt(document.querySelectorAll('.days_choosed')[choose_index].dataset.index)+1)].dataset.day);
							
						}	

						choose_index++;
					}
					
				}else{
						if(typeof(document.querySelectorAll('.days_choosed')[(parseInt(item.dataset.index)+1)]) == "undefined"){
								item.parentNode.parentNode.parentNode.children[1].value  = document.querySelectorAll('.days_choosed')[(parseInt(item.dataset.index)-1)].innerText;
								item.parentNode.parentNode.parentNode.children[1].dataset.id = document.querySelectorAll('.days_choosed')[(parseInt(item.dataset.index)-1)].dataset.day;
								document.querySelectorAll('.days_choosed')[parseInt(item.dataset.index)].style.display = 'none';
								//document.querySelectorAll('.days_choosed')[parseInt(item.dataset.index)].remove();
								window.location = response;
							}else{
								item.parentNode.parentNode.parentNode.children[1].value  = document.querySelectorAll('.days_choosed')[(parseInt(item.dataset.index)+1)].innerText;
								item.parentNode.parentNode.parentNode.children[1].dataset.id = document.querySelectorAll('.days_choosed')[(parseInt(item.dataset.index)+1)].dataset.day;
								document.querySelectorAll('.days_choosed')[parseInt(item.dataset.index)].style.display = 'none';
								

							}
				}
						}
					}

		
				});
				
				
			}
		});
	</script>
</body>
</html>