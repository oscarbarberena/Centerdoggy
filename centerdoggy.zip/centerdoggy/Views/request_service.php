<?php 
session_start();

// if(isset($_SESSION['email']) || isset($_SESSION['id_user'])){
// 	//$info = $this->getinfo($_SESSION['id_user'],"lenders");
// }else{
// 	header('Location: http://localhost:8089/centerdoggy/signin/');
// }


 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">reservas</a></li>
			<li class="list_"><div class="input_button"><a href="signin.html" class=" button_ b_green btn_option_user">Mi perfil</a></div>
				<div class="sub_options_">
                <div class="list_option">
                    <a href="/centerdoggy/profile/<?php echo $_SESSION['id_user']; ?>" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/signout/close_sesion/<?php echo $_SESSION['id_user'];?>" class="link_">Salir</a>
                </div>
            </div>
			</li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
		<div class="content_info" style="padding: 0px;">
			<div class="panel_head">
				<h1 class="title_">Solicitudes para tu servició</h1>
				<p class="info_">Aqui puedes ver quien,cuando y a que horas solicitan tu servició </p>
			</div>
			<div class="panel_body">
				<div class="container_table">
					<div class="panel_head">
						<h2 class="title_">Lista de solicitudes</h2>
						<div class="head_table">
							<li class="list_ list_id">
								<p class="info_">ID</p>
							</li>
							<li class="list_">
								<p class="info_">Solicitante</p>
							</li>
							<li class="list_">
								<p class="info_">Mascota</p>
							</li>
							<li class="list_">
								<p class="info_">Fecha del servició</p>
							</li>
							<li class="list_">
								<p class="info_">Estado</p>
							</li>
							<li class="list_">
								<p class="info_">Acciones</p>
							</li>
						</div>
					</div>
					<div class="panel_body">
						<?php $this->list_request_service($_GET['service']); ?>

					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>
		document.querySelector('.btn_option_user').addEventListener("click", function(e){
			e.preventDefault();
			$('.sub_options_').toggle();
		});
	</script>
</body>
</html>