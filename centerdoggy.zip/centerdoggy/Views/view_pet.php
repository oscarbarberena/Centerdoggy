<?php 
session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
    <a href="<?php $url = ($_SESSION['location'] == "admin") ? '/centerdoggy/pets/' : '/centerdoggy/my_pets/'; echo $url; ?>" type="button" class="btn_prev"><svg width="44" height="44" viewBox="0 0 24 24" class="mc-icon mc-icon-template-stateless mc-icon-template-stateless--right left-icon spectrum-hack-rotate-icon" style="transform: rotate(180deg);"><path d="M10.414 7.05l4.95 4.95-4.95 4.95L9 15.534 12.536 12 9 8.464z" fill="#637282" fill-rule="evenodd"></path></svg></a>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section c_green">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">Como funciona</a></li>
			<li class="list_"><a href="signin.html" class="link_section button_ b_green btn_option_user">Mi perfil</a>
				<div class="sub_options_">
                <div class="list_option">
                    <a href="/centerdoggy/profile/<?php echo $_SESSION['id_owner']; ?>" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Mis mascotas</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/signout/close_sesion/<?php echo $_SESSION['id_user'];?>/" class="link_">Salir</a>
                </div>
            </div>
			</li>
			
		</ul>
	</nav>
</header>
<body>
    <div class="window_modal">
        <div class="container_select">
            <button type="button" class="btn_close">x</button>
            <p class="info_select">¿Necesitas un veterinario para el registro del historial clinico de esta mascota?</p>
            <div class="container_button">
                <div class="input_button">
                    <a href="#" class="button_ b_green direction_info">Buscar veterinario</a>
                </div>
                <div class="input_button">
                    <a href="/centerdoggy/medical_history_/" class="button_ b_wgreen direction_register_">Ya tengo veterianario</a>
                </div>
            </div>
        </div>
    </div>
	<div class="container_">
        <div class="content_info">
            <div class="container_info_lender_current" style="margin-top: 10px; width: 65%;">
                <div class="container_division_info_user">
                  <div class="panel_left">
                    <div class="container_image"><img src="http://localhost:8089/centerdoggy/Views/<?php echo $this->get_info_()['picture']; ?>" alt="" class="image_user"></div>
                  </div>
                  <div class="panel_right">
                    <a href="#" class="direction_profile name_user"><?php echo $this->get_info_()['name_pet']; ?></a>
                    <p class="short_description_user" style="margin-bottom: 10px;">A esta mascota le encanta que sean cariñosa y jueguen con ella</p>
                    </div>
                  </div>
            </div>
        </div>
        </div>
		<div class="container_info_profile">
       <div class="panel_center">
         <div class="container_form form_white" style="margin-top:35px; height: 350px;">
             <form action="" class="form_ form_rgone form_view_info_user" data-url="/centerdoggy/my_pets/update_info/">
                 <div class="input_group">
                     <input type="text" name="name_pet" id="name_pet" class="textfield name_pet" value="<?php echo $this->get_info_()['name_pet']; ?>">
                     <label for="name_complete" class="lb_info">Nombre de la mascota</label>
                 </div>
                 <div class="input_group">
                     <input type="date" name="date_pet" id="date_pet" class="textfield date_pet" value="<?php echo $this->get_info_()['date_nacimiento']; ?>">
                     <label for="date_pet" class="lb_info">Fecha de nacimiento</label>
                 </div>
                 <div class="input_group">
                     <input type="text" name="color_pet" id="color_pet" class="textfield color_pet" value="<?php echo $this->get_info_()['color']; ?>">
                       <label for="color_pet" class="lb_info">Color</label>
                 </div>
                 <div class="input_button input_mhistory">
                     <button type="button" class="button_ b_wgreen btn_ch">Historial clinico</button>
                 </div>
                 <div class="input_group">
                    <div class="input_button">
                        <input type="file" name="picture_pet" id="picture_pet" style="display: none;" class="picture_pet">  
                        <label for="picture_pet" class="button_ b_wgreen" style="cursor: pointer;">Añadir una foto</label>
                    </div>
                     <label for="code_indentify" class="lb_info" style="left:0px;">Foto</label>
                 </div>
                <!--   <div class="input_group">
                     <input type="text" name="short_description" id="short_description" class="textfield short_description" autofocus="On">
                     <label for="short_description" class="lb_info">Descripción corta</label>
                 </div> -->
                 <div class="input_group" style="top:-25px;">
                   <div class="input_button">
                     <button type="submit" class="button_ b_green btn_snd">Editar información</button>
                   </div>
                 </div>
             </form>
             <div class="form_loader">
                 <div class="container_loader" style="top:60px;">
                     <div class="bar_loader">
                       <div class="loader"></div>
                         <img src="img/padlock.svg" alt="">
                     </div>
                     <p class="info_">cargando la informacion ...</p>
                 </div>
             </div>
         </div>
       </div>
     </div>
     <div class="toast">Hemos registrado tu servicio correctamente!!</div>
	</div>
    <script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
    <script>
        document.querySelector('.btn_option_user').addEventListener("click", function(e){
            e.preventDefault();
            $('.sub_options_').toggle();
        });

        var file = "img/dog_service.png";
        //add_pet
        document.querySelector('.picture_pet').addEventListener('change', e =>{
           file = this.files[0];
        });

        function toast(text){
            var t = document.querySelector('.toast');
            t.innerHTML = text;
            t.classList.add('active');

            setTimeout(function(){
                t.classList.remove('active');   
            }, 6000);
        }

        function getParameterByName(name){
            name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
            var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
            return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
        }

        function getId(){
            const URL = window.location.href;
            let data = URL.split('/');
            if(data.length >= 8){
                console.log(data[6]);
               return data[6];    
            }
            
        }   
        
        document.querySelector('.btn_snd').addEventListener('click', e =>{
            e.preventDefault();
            var url      = document.querySelector('.form_view_info_user').dataset.url;
            var name     = document.querySelector('.name_pet').value;
            var date_pet = document.querySelector('.date_pet').value;
            var color    = document.querySelector('.color_pet').value;
            var picture  = file;
            
            if(name == "" && date_pet == "" && color == ""){
                console.log("emptys");
            }else if(name == ""){

            }else if(date_pet == ""){
                console.log('date empty');
            }else if(color == ""){
                console.log('color empty');
            }else{
                console.log('send data...');
              let id_ =   getId();
                 $.ajax({
                    url:url,
                    type:"POST",
                    data:{id_pet:id_,name_pet:name,fecha_nacimiento:date_pet,color:color,picture:file},
                    beforeSend:function(){
                        document.querySelector('.form_loader').style.visibility = 'visible';
                    },
                    complete: function(){
                        document.querySelector('.form_loader').style.visibility = 'hidden';
                    },
                    success: function(data){
                        console.log(data);
                        if(data == "failed"){

                        }else{
                            toast("<b>Felicidades!</b> la información de tu mascota fue actualizada con exito");
                        }
                    }

                }).done(function(){
                    //$('input').val('');
                });
            }
           
              
        });
        
        document.querySelector('.btn_ch').addEventListener('click' , e =>{
            e.preventDefault();
            document.querySelector('.window_modal').style.visibility = "visible";
        });

        document.querySelector('.direction_register_').addEventListener('click', e=>{
            e.preventDefault();

            let location = window.location.href;
            
            if(location.split('/').length >= 8 ){
               const URL =  e.target.getAttribute('href');
               let current_uri = URL+'?pet='+location.split('/')[6]+'&register=normal';
              window.location.href = current_uri;
            }
        });

    </script>
</body>
</html>