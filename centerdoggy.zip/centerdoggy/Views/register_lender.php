<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon_/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header border-bottom">
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_ right-30"><div class="input_button"><a href="signin.html" class=" button_  b_notification"><i class="icon-bell"></i></a></div></li>
			<li class="list_ right-30"><a href="#" class="link_section">Jhon Murillo Mendez</a></li>		
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
		<div class="pane_menu_navigation">
			<div class="section_logo">
				<a href="#" class="logo_portal"><i class="icon-dog-paw"></i></a>
			</div>
			<div class="navigation">
				<li class="list_"><a href="/centerdoggy/portal_admin/" class="section_"><i class="icon-home"></i></a></li>
				<li class="list_"><a href="/centerdoggy/lenders/" class="section_ active"><i class="icon-avatar"></i></a></li>
				<li class="list_"><a href="/centerdoggy/pets/" class="section_"><i class="icon-zynga-logotype"></i></a></li>
				<li class="list_"><a href="/centerdoggy/veterinarians_/" class="section_"><i class="icon-pet"></i></a></li>
				<li class="list_"><a href="/centerdoggy/offices_/" class="section_"><i class="icon-hotel"></i></a></li>
			</div>
		</div>
		<div class="content_info pane_section">
			<div class="content_title center p-x30 m_bottomx60">
				<h2 class="title_ t_green">Estos los Prestadores, que trabajan con nosotros</h2>
				<p class="info_">Administra los usuarios del sistemas!</p>
			</div>
			
			<span class="alert_">Upps! Ha ocurrido un error dificilisimo</span>
			<div class="container_form form_center form_white form_shadow" style="width:80%;">
				<form action="/centerdoggy/register_carer/add_lender/" class="form_" method="POST">
					<div class="division_fields">
						<div class="input_group"><input type="text" name="" id="field_codes" class="textfield field_codes" placeholder="CC:"></div>
					<div class="input_group"><input type="text" name="" id="field_name" class="textfield field_name" placeholder="Nombre y apellido"></div>
					</div>
					<div class="input_group">
						<select name="" id="field_sex" class="textfield field_sex">
							<option value="default">Selecciona tu sexo</option>
							<option value="Hombre">Hombre</option>
							<option value="Mujer">Mujer</option>
						</select>
					</div>
					<div class="division_fields">	
						<div class="input_group"><input type="text" name="" id=" field_phone" class="textfield field_phone" placeholder="Telefono celular"></div>
						<div class="input_group"><input type="text" name="" id="field_email" class="textfield field_email" placeholder="Correo electronico"></div>
					</div>
					<div class="input_group"><input type="password" name="" id=" field_password" class="textfield field_password" placeholder="Password"></div>
					<div class="input_group" style="display: flex; align-items: center;">
						<div class="input_checkbox input_auto" style="visibility: visible;"><input type="checkbox" name="select_one" class="select_days_" id="select_one" data-rol="-1"><label for="select_one" class="checkbox_"><i class="icon-checkmark"></i></label>Cuidador</div>
						<div class="input_checkbox input_auto" style="visibility: visible;"><input type="checkbox" name="select_one" class="select_days_" id="select_two" data-rol="-2"><label for="select_two" class="checkbox_"><i class="icon-checkmark"></i></label>Paseador</div>
						<div class="input_checkbox input_auto" style="visibility: visible;"><input type="checkbox" name="select_one" class="select_days_" id="select_three" data-rol="-3"><label for="select_three" class="checkbox_"><i class="icon-checkmark"></i></label>Grooming</div>
						<!-- <select name="" id=" field_rol" class="textfield field_rol">
							<option value="1">Cuidador</option>
		                    <option value="2">Paseador</option>
		                    <option value="3">Spa Grooming</option>
		                    <option value="4">Ciudador, Paseador, Grooming</option>
		                    <option value="5">Paseador, Grooming</option>
		                    <option value="6">Ciudador, Grooming</option>
		                    <option value="8">Ciudador, Paseador</option>
						</select> -->
					</div>
					<div class="division_fields">	
						<div class="input_group">
									<select name="" id="field_city" class="textfield field_city">
											<option value="default">Ciudad de tu ubicación</option>
											<option value="Cali">Santiago de Cali</option>
											<option value="Bogota">Bogota</option>
											<option value="Medellin">Medellin</option>
									</select>
						</div>
						<div class="input_group"><input type="text" name="" id=" field_neit" class="textfield field_neit" placeholder="Barrio de influencia"></div>
					</div>
					<div class="input_group">
						<div class="input_button">
							<button type="submit" class="button_ b_green btn_snd btn_send__">Registrarme</button>
						</div>
					</div>
				</form>
				<div class="form_loader">
	              <div class="container_loader">
	                  <div class="bar_loader">
	                    <div class="loader"></div>
	                      <img src="<?php echo rute__folder;?>img/padlock.svg" alt="">
	                  </div>
	                  <p class="info_">Estamos registrandote...</p>
	              </div>
          		</div>
			</div>
		</div>
		
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script src="<?php echo rute__folder;?>js/module_init.js"></script>
	<script>
		// document.querySelector('.btn_controls').addEventListener("click", function(e){
		// 	e.preventDefault();
		// 	$('.sub_controls_').toggle();
		// });
// 		var module_ = (function(){

// 	var obj = {};
// 	var select_rol = "";

// 	var init = function(){
// 		staritems();
// 		add_events();
// 	};


// 	var staritems = function(){
// 		obj.btn_snd  = document.querySelector('.btn_send_');
// 		obj.btn_snd_ = document.querySelector('.btn_send__');
// 		obj.fields = {
// 			codes: document.querySelector('.field_codes'),
// 			name_user:  document.querySelector('.field_name'),
// 			sex:   document.querySelector('.field_sex'),
// 			email: document.querySelector('.field_email'),
// 			pass:  document.querySelector('.field_password'),
// 			phone: document.querySelector('.field_phone'),
// 			city:  document.querySelector('.field_city'),
// 			neit: document.querySelector('.field_neit'),
// 			rol:  document.querySelector('.field_rol')

// 		};
// 		obj.alert = document.querySelector('.alert_');

// 	};

// 	var add_events = function(){
// 		if(typeof(document.querySelector('.btn_send_')) == "undefined" || obj.btn_snd == null){
			
// 		}else{
// 			obj.btn_snd.addEventListener("click",events.register_owner);
			
// 		}

// 		if(typeof(document.querySelector('.btn_send__')) == "undefined" || obj.btn_snd_ == null){

// 		}else{
// 			obj.btn_snd_.addEventListener("click",events.register_lender);
// 		}
		
		
		
		
// 	};

// 	function http_request(url_,method,data_,before_s,com_,success_){
// 		$.ajax({url:url_,type:method,data:data_,beforeSend: before_s,complete:com_,success: success_});
// 	}

// 	function before_s(){
// 		//obj.btn_snd.disabled = true;
// 		document.querySelector('.form_loader').style.visibility = 'visible';

// 	}

// 	function com_(){
// 		//obj.btn_snd.disabled = false;
// 		document.querySelector('.form_loader').style.visibility = 'hidden';		
// 	}

// 	function success_(data){
// 		console.log(data);
// 		if(data == "failed"){
// 			obj.alert.innerHTML = "<strong>Upps!</strong> Ah ocurrido un error en tu peticion, por favor intente de nuevo mas tarde";
// 			obj.alert.classList.remove('alert_success');
// 			obj.alert.classList.add('alert_error');
// 		}else{
// 			obj.alert.innerHTML = "<strong>Felicidades!</strong> Tu registro, se ha realizado de manera exitosa, hemos enviado a tu correo un mensaje de bienvenida";
// 			obj.alert.classList.remove('alert_error');
// 			obj.alert.classList.add('alert_success');
// 			$('input').val('');
// 			$('select').val('');
// 		}
// 	}

// 	function success__(data){
// 		console.log(data);
// 		if(data == "failed"){
// 			obj.alert.innerHTML = "<strong>Upps!</strong> Ah ocurrido un error en tu peticion, por favor intente de nuevo mas tarde";
// 			obj.alert.classList.remove('alert_success');
// 			obj.alert.classList.add('alert_error');
// 		}else{
// 			obj.alert.innerHTML = "<strong>Felicidades!</strong> Hemos registrado a este prestador de manera exitosa";
// 			obj.alert.classList.remove('alert_error');
// 			obj.alert.classList.add('alert_success');
// 			$('input').val('');
// 			$('select').val('');
// 		}
// 	}

// 	var events = {
		

// 		register_lender: function(e){
// 			e.preventDefault();
// 			select_rol = "";
// 			[].forEach.call(document.querySelectorAll('.select_days_'),item => {

// 					if(item.checked){
// 						console.log(item.dataset.rol);

// 						select_rol += item.dataset.rol;
// 					}
// 			});
// 			if(obj.fields.name_user.value == "" && obj.fields.sex.value == "defult" && obj.fields.email.value == "" && obj.fields.pass.value == "" && select_rol == ""){
// 				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
// 				obj.alert.classList.add('alert_error');
// 			}else if(obj.fields.name_user.value == ""){
// 				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
// 				obj.alert.classList.add('alert_error');
// 			}else if(obj.fields.sex.value == "defult"){
// 				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
// 				obj.alert.classList.add('alert_error');
// 			}else if(obj.fields.email.value == ""){
// 				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
// 				obj.alert.classList.add('alert_error');
// 			}else if(obj.fields.pass.value == ""){
// 				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
// 				obj.alert.classList.add('alert_error');
// 			}else if(select_rol == ""){
// 				obj.alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
// 				obj.alert.classList.add('alert_error');
// 			}else{
// 				obj.alert.classList.remove('alert_error');
// 				let url_ = document.querySelector('.form_').getAttribute('action');
// 				var roles = select_rol;				

				
// 				let data_ = {
// 					code_lender: obj.fields.codes.value,
// 					name_lender:obj.fields.name_user.value,
// 					sex: obj.fields.sex.value,
// 					email:obj.fields.email.value,
// 					password:obj.fields.pass.value,
// 					city_lender: obj.fields.city.value,
// 					neit_lender: obj.fields.neit.value,
// 					phone:obj.fields.phone.value,
// 					rol:roles

// 				};  
// 				 http_request(url_,"POST",data_,before_s,com_,success__);
// 			}
// 		}
// 	}


// 	return {
// 		__construct:init
// 	}


// }());

// module_.__construct();
	</script>
</body>
</html>