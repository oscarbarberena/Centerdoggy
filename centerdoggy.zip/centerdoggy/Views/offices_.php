<?php 
session_start();

// if(isset($_SESSION['email']) || isset($_SESSION['id_user'])){
// 	//$info = $this->getinfo($_SESSION['id_user'],"owners");
// }else{
// 	header('Location: http://localhost:8089/centerdoggy/signin/');
// }


 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
	<a href="/centerdoggy/portal_owner/" class="logo_icono" style="position:absolute;left:15px;top:10px;z-index: 200;">
		<h1 class="name_company">PET_CENTER</h1>
	</a>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section c_green">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">reservas</a></li>
			<li class="list_"><a href="signin.html" class="link_section btn_option_user">Mi perfil</a><div class="sub_options_">
                <div class="list_option">
                    <a href="/centerdoggy/profile/<?php echo $_SESSION['id_user']; ?>/" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/my_pets/" class="link_">Mis mascotas</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/signout/close_sesion/<?php echo $_SESSION['id_user'];?>" class="link_">Salir</a>
                </div>
            </div></li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
		<div class="content_info pane_section">
			<div class="content_title center p-x30 m_bottomx60">
				<h2 class="title_ t_green">Estos son los consultorios que estan registrados en el portal</h2>
				<p class="info_">Escoje a tu gusto y comodida el consultorio para tu mascota!</p>
			</div>
			<div class="container_search">
				<div class="input_group">
					<input type="text" name="" id="" class="textfield" placeholder="Busca a un veterinario...">
				</div>
				
				<div class="input_button">
					<button type="button" class="button_ b_green">Buscar</button>
				</div>
			</div>
			<div class="content_box flex wrap" id="content_veterinarians" style="justify-content: center;"></div>
		</div>
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>
		fetch('/centerdoggy/offices_/list_all/',{
			method:'POST'	
		})
		.then(response => {
				return response.json();
		})
		.then(result => {
			if(result.hasOwnProperty("data")){
				if(result.data == "empty"){
					console.log('No hay datos');
					document.getElementById('content_veterinarians').innerHTML = '<div style="display:block; padding:25px;"><p>Aun no hay consultorios tu o tus mascotas</p></div>';
				}
			}else{
				console.log(result);
				var dom = "";
				 result.map((item,index) => {
				 		dom += `<a href="#" class="box_ b_mtx30 box_consultorios">
					<div class="box_info  box_service">
						<div class="panel_head">
							<div class="input_checkbox" style="right:35px;">
								<input type="checkbox" name="check_select" id="select_this_${result[index].id_vet}" data-id="${result[index].id_vet}" onchange="select_(this);">
								<label for="select_this_${result[index].id_vet}" class="checkbox_"><i class="icon-checkmark"></i></label>
							</div>
							<h1 class="name_">Consultorio</h1>
							<p class="text_location">Barrio</p>
							<strong class="text_location">${result[index].neit}</strong>	
							
						</div>
						<div class="panel_body">
							<p class="name_">Información de contacto</p>
							<p class="description_short">Ubicación: ${result[index].address}</p>
							<p class="description_short">Telefono: ${result[index].telefono}</p>
							<p class="description_short">Email: ${result[index].email}</p>
						</div>
					</div>
				</a>`;
				 });	
					
				document.getElementById('content_veterinarians').innerHTML = dom;
			}


				
		});
	</script>
</body>
</html>
