<?php 
session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header" style="border-bottom:1px solid #dedede; height: 80px;">
	<a href="/centerdoggy/portal_owner/" class="logo_icono" style="position:absolute;left:15px;top:10px;z-index: 200;">
		<h1 class="name_company">PET_CENTER</h1>
	</a>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section c_green">Premium</a></li>
			<li class="list_"><a href="#" class="link_section">Como funciona</a></li>
			<li class="list_"><a href="signin.html" class="link_section button_ b_green btn_option_user">Mi perfil</a><div class="sub_options_">
                <div class="list_option">
                    <a href="/centerdoggy/profile/<?php echo $_SESSION['id_owner']; ?>" class="link_">Mis perfil</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/my_pets/" class="link_">Mis mascotas</a>
                </div>
                <div class="list_option">
                  <a href="#" class="link_">Configuraciones</a>
                </div>
                <div class="list_option">
                  <a href="/centerdoggy/signout/close_sesion/<?php echo $_SESSION["id_user"]; ?>" class="link_">Salir</a>
                </div>
            </div></li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="window_modal">
		<div class="container_select">
			<button type="button" class="btn_close">x</button>
			<p class="info_select">¿Deseas ver la información de este prestador o quieres separar tu servició ya?</p>
			<div class="container_button">
				<div class="input_button">
					<a href="#" class="button_ b_green direction_info">Ver información</a>
				</div>
				<div class="input_button">
					<a href="/centerdoggy/calendar_lender/view_calendar/?lender=" class="button_ b_wgreen load_schedule">Solicitar servició</a>
				</div>
			</div>
		</div>
	</div>
	<div class="container_">
		<div class="content_info">
			<div class="content_title center p-x30 m_bottomx60">
				<h2 class="title_ t_green">Estos los <?php echo $_GET['type_service']."es"; ?>, que trabajan con nosotros</h2>
				<p class="info_">Selecciona la mejor opción para tu mascota, recuerda hacer la reserva ya!</p>
			</div>
			<div class="container_search">
				<div class="input_group">
					<input type="text" name="" id="" class="textfield" placeholder="Busca a un cuidador...">
				</div>
				<div class="input_button">
					<button type="button" class="button_ b_green">Buscar</button>
				</div>
			</div>
			<div class="content_box flex wrap" style="width: 70%;">
				<?php 
					$this->load_all_lenders($_GET['type_service']);
					
				 ?>
			</div>
		</div>
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>
		
		function getParameterByName(name){
		    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
		    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
		    results = regex.exec(location.search);
		    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
		}

		function show_option(e){
			e.preventDefault();
			console.log(this.getAttribute('href'));
			document.querySelector('.window_modal').style.visibility = "visible";
			document.querySelector('.direction_info').setAttribute("href",this.getAttribute('href'));
			document.querySelector('.load_schedule').setAttribute("href",document.querySelector('.load_schedule').getAttribute("href")+this.dataset.iduser+'&service='+getParameterByName('nsrv'));
		}
		
		[].forEach.call(document.querySelectorAll('.box_user'),box => {
			box.addEventListener('click', show_option);
		});
		
		document.querySelector('.btn_close').addEventListener('click', function(e){
			e.preventDefault();
			document.querySelector('.window_modal').style.visibility = "hidden";
			
			//
		});
		document.querySelector('.btn_option_user').addEventListener("click", function(e){
			e.preventDefault();
			$('.sub_options_').toggle();
		});
	</script>
</body>
</html>