<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon_/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header border-bottom">
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_ right-30"><div class="input_button"><a href="signin.html" class=" button_  b_notification"><i class="icon-bell"></i></a></div></li>
			<li class="list_ right-30"><a href="#" class="link_section">Jhon Murillo Mendez</a></li>		
		</ul>
	</nav>
</header>
<body>
	<div class="window_modal">
		<div class="container_select" style="height:170px;">
			<button type="button" class="btn_close">x</button>
			<p class="info_select">¿Deseas eliminar esta mascota?</p>
			<div class="container_button" style="width: 90%; display: flex; justify-content: center;">
				<div class="input_button">
					<a href="#drop" class="button_ b_green direction_info btn_delete_">Eliminar</a>
				</div>
				<div class="input_button">
					<a href="#cancel" class="button_ b_wgreen load_schedule">Cancelar</a>
				</div>
			</div>
		</div>
	</div>
	<div class="container_">
		<div class="pane_menu_navigation">
			<div class="section_logo">
				<a href="#" class="logo_portal"><i class="icon-dog-paw"></i></a>
			</div>
			<div class="navigation">
				<li class="list_"><a href="/centerdoggy/portal_admin/" class="section_"><i class="icon-home"></i></a></li>
				<li class="list_"><a href="/centerdoggy/lenders/" class="section_"><i class="icon-avatar"></i></a></li>
				<li class="list_"><a href="/centerdoggy/pets/" class="section_"><i class="icon-zynga-logotype"></i></a></li>
				<li class="list_"><a href="/centerdoggy/veterinarians_/" class="section_ active"><i class="icon-pet"></i></a></li>
				<li class="list_"><a href="/centerdoggy/offices_/" class="section_"><i class="icon-hotel"></i></a></li>
			</div>
		</div>
		<div class="content_info pane_section">
			<div class="content_title center p-x30 m_bottomx60">
				<h2 class="title_ t_green">Agrega nuevos veterinarios</h2>
				<p class="info_">Administra los veterinarios que estan dentro del portal</p>
			</div>
			<span class="alert_" style="top:0px;">Upps! Ha ocurrido un error dificilisimo</span>
			<div class="container_form form_center form_white form_shadow" style="width:80%;">
				<form action="/centerdoggy/register_carer/add_lender/" class="form_" method="POST">
					<div class="input_group"><input type="text" name="" id="field_codes" class="textfield field_codes" placeholder="CC:"></div>
					<div class="input_group"><input type="text" name="" id="field_name" class="textfield field_name" placeholder="Nombre y apellido"></div>
					<div class="input_group">
						<select name="" id="field_sex" class="textfield field_sex">
							<option value="default">Selecciona tu sexo</option>
							<option value="Hombre">Hombre</option>
							<option value="Mujer">Mujer</option>
						</select>
					</div>
					<div class="input_group"><input type="text" name="" id="field_phone" class="textfield field_phone" placeholder="Telefono celular"></div>
					<div class="input_group"><input type="text" name="" id="field_address" class="textfield field_address" placeholder="Direccion de vivienda"></div>
					<div class="input_group"><input type="text" name="" id="field_email" class="textfield field_email" placeholder="Correo electronico"></div>
					<div class="input_group"><input type="password" name="" id="field_password" class="textfield field_password" placeholder="Password"></div>
					<div class="input_group">
						<select name="" id="field_city" class="textfield field_city">
							<option value="default">Ciudad de tu ubicación</option>
							<option value="Cali">Santiago de Cali</option>
							<option value="Bogota">Bogota</option>
							<option value="Medellin">Medellin</option>
						</select>
					</div>
					<div class="input_group"><input type="text" name="" id="field_neit" class="textfield field_neit" placeholder="Barrio de influencia"></div>
					<div class="input_group">
						<div class="input_button">
							<button type="submit" class="button_ b_green btn_snd btn_send__">Guardar</button>
						</div>
					</div>
				</form>
				<div class="form_loader">
	              <div class="container_loader">
	                  <div class="bar_loader">
	                    <div class="loader"></div>
	                      <img src="<?php echo rute__folder;?>img/padlock.svg" alt="">
	                  </div>
	                  <p class="info_">Estamos registrandote...</p>
	              </div>
          		</div>
			</div>
		</div>
		
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>
		var alert = document.querySelector('.alert_');
		var fields = {
			codes: document.querySelector('.field_codes'),
			name_user:  document.querySelector('.field_name'),
			sex:   document.querySelector('.field_sex'),
			email: document.querySelector('.field_email'),
			pass:  document.querySelector('.field_password'),
			phone: document.querySelector('.field_phone'),
			city:  document.querySelector('.field_city'),
			neit: document.querySelector('.field_neit'),
			address:  document.querySelector('.field_address')

		};

		document.querySelector('.btn_send__').addEventListener('click', e => {
			e.preventDefault();
			if(fields.codes.value == "" && fields.name_user.value == "" && fields.sex.value == "defult" &&  fields.phone.value == "" && fields.email.value == "" && fields.pass.value == "" && fields.address.value == ""){
				alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				alert.classList.add('alert_error');
			}else if(fields.codes.value == ""){
				alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				alert.classList.add('alert_error');
			}else if(fields.name_user.value == ""){
				alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				alert.classList.add('alert_error');
			}else if(fields.sex.value == "defult"){
				alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				alert.classList.add('alert_error');
			}else if(fields.phone.value == ""){
				alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				alert.classList.add('alert_error');
			}else if(fields.email.value == ""){
				alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				alert.classList.add('alert_error');
			}else if(fields.pass.value == ""){
				alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				alert.classList.add('alert_error');
			}else if(fields.address.value == ""){
				alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				alert.classList.add('alert_error');
			}else if(fields.city.value == ""){
				alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				alert.classList.add('alert_error');
			}else if(fields.neit.value == ""){
				alert.innerHTML = "<strong>Error!</strong> debes completar todos los datos para continuar";
				alert.classList.add('alert_error');
			}else{
				alert.classList.remove('alert_error');
				console.log('send...');
				$.ajax({
					url:'/centerdoggy/veterinarians_/register/',
					type:'POST',
					data:{
						code:fields.codes.value,
						name:fields.name_user.value,
						sex:fields.sex.value,
						phone:fields.phone.value,
						address:fields.address.value,
						email:fields.email.value,
						password:fields.pass.value,
						city:fields.city.value,
						neit:fields.neit.value
					},
					success: function(response){
						console.log(response);
						if(response == "failed"){

						}else{
							alert.innerHTML = "<strong>Felicidades!</strong> El veterinario se registro con exito";
							alert.classList.remove('alert_error');
							alert.classList.add('alert_success');
						}
					}
				}).done(function(){
					$('select').val("");
					$('input').val("");
				})
			}
		});
	</script>
</body>
</html>