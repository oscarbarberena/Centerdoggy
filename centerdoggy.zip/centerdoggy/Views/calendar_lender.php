<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon/style.css">
</head>
<header class="main_header">
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="#" class="link_section">Nuestros servicios</a></li>
			<li class="list_"><a href="#" class="link_section">Como funciona</a></li>
			<li class="list_"><div class="input_button"><a href="signin.html" class=" button_ b_green">Iniciar Sesión</a></div></li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_" style="height:auto;">
		<div class="content_info">
			<div class="content_title center">
				<h2 class="title_ t_green">Selecciona tus días laborales</h2>
				<p class="info_">Tienes la libertad de poder acomodar tu horario a tus disponibilidad</p>
			</div>
			
		</div>
		<div class="content_info"  style="height:auto;">
			<div class="container_months">
				<button type="button" class="btn_slide btn_prev" data-direction="prev"><</button>
				<div class="slide_months">
					<li class="month_">
						<p class="month" data-month="0">Enero</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="1">
						<p class="month">Febrero</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="2">
						<p class="month">Marzo</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="3">
						<p class="month">Abril</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="4">
						<p class="month">Mayo</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="5">
						<p class="month">Junio</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="6">
						<p class="month">Julio</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="7">
						<p class="month">Agosto</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="8">
						<p class="month">Septiembre</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="9">
						<p class="month">Octubre</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="10">
						<p class="month">Noviembre</p>
						<p class="year_current">0</p>
					</li>
					<li class="month_" data-month="11">
						<p class="month">Diciembre</p>
						<p class="year_current">0</p>
					</li>
				</div>
				<button type="button" class="btn_slide btn_next" data-direction="next">></button>
			</div>
			<div class="container_calendar" style="margin-bottom: 25px; border-bottom: 1px solid #dedede; padding-bottom: 20px;">
				<div class="panel_head" style="border-bottom: 1px solid transparent; margin-top: 14px; left:45px; background: #fff;">
					<div class="list_days" style="width: auto; margin-right: 36px;">
						<div class="input_checkbox" style="visibility: visible;">	
								<input type="checkbox" name="select_one" class="select_all_days" id="select_one" data-row="0">
								<label for="select_one" class="checkbox_"><i class="icon-checkmark"></i></label>
						</div>
					</div>
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="1-">Lunes</button>
						</div>
					</div>
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="-2">Martes</button>
						</div>
					</div>
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="-3">Miercoles</button>
						</div>
					</div>
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="-4">Jueves</button>
						</div>
					</div>
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="-5">Viernes</button>
						</div>
					</div>
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="-6">Sabado</button>
						</div>
					</div>
					<div class="list_days">
						<div class="input_button">
							<button class="button_ b_wgreen b_wgreen_" data-day="-6">Domingo</button>
						</div>
					</div>
				</div>
				<div class="panel_body list_btn_days">
					
				</div>
			</div>
			<!-- <div class="container_time">
				<div class="input_group">
					<label for="" class="lb_info">Hora de inicio</label>
					<input type="time" name="" id="field_starttime" class="textfield field_starttime" placeholder="0:00"></div>
				<div class="input_group">
					<label for="" class="lb_info">Hora de fin</label>
					<input type="time" name="" id="field_endtime" class="textfield field_endtime" placeholder="0:00"></div>
			</div> -->
			<div class="input_group w-x70" style="margin:auto;">
				<div class="input_button" style="transform: translateX(50%); display: block;">
					<button type="submit" class="button_ b_green btn_send_">Continuar</button>
				</div>
			</div>
		</div>
		<div class="form_loader">
	         <div class="container_loader">
	               <div class="bar_loader">
	               <div class="loader"></div>
	                <img src="<?php echo rute__folder;?>img/padlock.svg" alt="">
	          </div>
	            <p class="info_">Estamos registrandote...</p>
	          </div>
        </div>
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>

		var mes_text = [
			 "Enero",
			 "Febrero",
			 "Marzo",
			 "Abril",
			 "Mayo",
			 "Junio",
			 "Julio",
			 "Agosto",
			 "Septiembre",
			 "Octubre",
			 "Noviembre", 
			 "Diciembre"
		 ];

		var dias = ["d", "l", "m", "mi", "j", "v", "s"];
		var fecha_calendar = new Date();
		
		
		
    	

		function fechaPorDia(año, dia) {
 				 var date = new Date(año, 0);
  					return new Date(date.setDate(dia));
		}
		

		var slide_months = 12;
		var index = 0;

		function dia_s_inicio(d,month_current){
			var fecha = "";
			 var ano = "";
			if(month_current == "default"){
				fecha = new Date();
				ano = fecha.getFullYear();
			}else{
				fecha = new Date();

				fecha.setMonth((month_current-1));
				console.log(fecha.getFullYear() > new Date().getMonth());
				if(fecha.getMonth() == 0 && fecha.getFullYear() > new Date().getMonth()){
					fecha.setFullYear((fecha.getFullYear()+1));
					ano = fecha.getFullYear();
					console.log('sssss'+fecha.getFullYear());
				}
			}
			 

			 

			 var mes = fecha.getMonth()+1; //obteniendo mes
			 var dia = d;
		     //obteniendo año
			if(dia<10)
				  dia='0'+dia; //agrega cero si el menor de 10
			if(mes<10)
				 mes='0'+mes //agrega cero si el menor de 10
				 var fec = (mes+"/"+dia+"/"+ano);
				 console.log('anio:'+fec);
				 var day = new Date(fec).getDay();
			console.log('Dia en semana que arranca --> '+ day);
			return dias[day];		    
		}

		var current = "";
		
		var ano = 0;

		function day_week_init(boolean,current_month,direction){
			 
			 
			 
			if(boolean == false){
				ano = fecha_calendar.getFullYear();
			}else{
				fecha_calendar.setMonth(current_month);
				
				if(mes_text[fecha_calendar.getMonth()]=="Enero"){
					if(direction == "next"){
						ano = fecha_calendar.getFullYear()+1;
						fecha_calendar.setFullYear(fecha_calendar.getFullYear());
						
						var years = document.querySelectorAll('.year_current');

						for(let i of years){
							i.textContent = ano;
						}
					}else{
						//ano = ano;
						ano = fecha_calendar.getFullYear();
						var years = document.querySelectorAll('.year_current');

						for(let i of years){
							i.textContent = ano;
						}
					}
				}else if(mes_text[fecha_calendar.getMonth()]=="Diciembre"){

					if(direction == "prev"){
						ano = fecha_calendar.getFullYear()-1;
						fecha_calendar.setFullYear(ano);
						
						var years = document.querySelectorAll('.year_current');

						for(let i of years){
							i.textContent = ano;
						}

						console.log('Prev para el retrazo de anio ' + ano);
					}else{
						console.log('Current year --> ' + ano + ' anio actual segun pc --> ' + fecha_calendar.getFullYear());
						if(ano > fecha_calendar.getFullYear()){
							console.log('si es mayor');
						}else{
							console.log('No es mayor');
						}
						//ano = fecha_calendar.getFullYear();
						fecha_calendar.setFullYear(ano);

						console.log('Next para el avance de anio '+ ano + ' hola ' + fecha_calendar.getFullYear());
						var years = document.querySelectorAll('.year_current');

						for(let i of years){
							i.textContent = ano;
						}
					}
				}else{

					if(direction == "next"){
						//ano = fecha_calendar.getFullYear()+1;
						fecha_calendar.setFullYear(ano);
						//console.log("Es momento de cambiar de anio:" + ano);
						var years = document.querySelectorAll('.year_current');

						for(let i of years){
							i.innerText = ano;
						}
						console.log('Next para los demas meses ' + ano);
						current = ano;
					}else{
						//ano = fecha_calendar.getFullYear();
						//console.log('no se: ' + ano);
						fecha_calendar.setFullYear(ano);
						var years = document.querySelectorAll('.year_current');

						for(let i of years){
							i.innerText = ano;
						}
						console.log('Prev para los demas meses ' + ano);
					}
				}
				
				
				
				
				
			}
			 

			 

			 var mes = fecha_calendar.getMonth()+1; //obteniendo mes
			 var dia = 1;
		     //obteniendo año
			if(dia<10)
				  dia='0'+dia; //agrega cero si el menor de 10
			if(mes<10)
				 mes='0'+mes //agrega cero si el menor de 10
				 var fec = (mes+"/"+dia+"/"+ano);
				 var day = new Date(fec).getDay();
			return dias[day];	
		}

		function day_week_init_days(boolean,current_month,direction,day_init_){
			 
			 
			 
			if(boolean == false){
				ano = fecha_calendar.getFullYear();
			}else{
				fecha_calendar.setMonth(current_month);
				
				if(mes_text[fecha_calendar.getMonth()]=="Enero"){
					if(direction == "next"){
						ano = fecha_calendar.getFullYear()+1;
						fecha_calendar.setFullYear(fecha_calendar.getFullYear());
						
						var years = document.querySelectorAll('.year_current');

						for(let i of years){
							i.textContent = ano;
						}
					}else{
						//ano = ano;
						ano = fecha_calendar.getFullYear();
						var years = document.querySelectorAll('.year_current');

						for(let i of years){
							i.textContent = ano;
						}
					}
				}else if(mes_text[fecha_calendar.getMonth()]=="Diciembre"){

					if(direction == "prev"){
						ano = fecha_calendar.getFullYear()-1;
						fecha_calendar.setFullYear(ano);
						
						var years = document.querySelectorAll('.year_current');

						for(let i of years){
							i.textContent = ano;
						}

						console.log('Prev para el retrazo de anio ' + ano);
					}else{
						console.log('Current year --> ' + ano + ' anio actual segun pc --> ' + fecha_calendar.getFullYear());
						if(ano > fecha_calendar.getFullYear()){
							console.log('si es mayor');
						}else{
							console.log('No es mayor');
						}
						//ano = fecha_calendar.getFullYear();
						fecha_calendar.setFullYear(ano);

						console.log('Next para el avance de anio '+ ano + ' hola ' + fecha_calendar.getFullYear());
						var years = document.querySelectorAll('.year_current');

						for(let i of years){
							i.textContent = ano;
						}
					}
				}else{

					if(direction == "next"){
						//ano = fecha_calendar.getFullYear()+1;
						fecha_calendar.setFullYear(ano);
						//console.log("Es momento de cambiar de anio:" + ano);
						var years = document.querySelectorAll('.year_current');

						for(let i of years){
							i.innerText = ano;
						}
						console.log('Next para los demas meses ' + ano);
						current = ano;
					}else{
						//ano = fecha_calendar.getFullYear();
						//console.log('no se: ' + ano);
						fecha_calendar.setFullYear(ano);
						var years = document.querySelectorAll('.year_current');

						for(let i of years){
							i.innerText = ano;
						}
						console.log('Prev para los demas meses ' + ano);
					}
				}
				
				
				
				
				
			}
			 

			 

			 var mes = fecha_calendar.getMonth()+1; //obteniendo mes
			 var dia = day_init_;
		     //obteniendo año
			if(dia<10)
				  dia='0'+dia; //agrega cero si el menor de 10
			if(mes<10)
				 mes='0'+mes //agrega cero si el menor de 10
				 var fec = (mes+"/"+dia+"/"+ano);
				 var day = new Date(fec).getDay();
			return dias[day];	
		}

		function get_limit_run(day__){

			var size_d = 0;

			switch (day__) {
				case "l":
					size_d = 1;
					break;
				case "m":
					size_d = 2;
					break;
				case "mi":
					size_d = 3;
					break;
				case "j":
					size_d = 4;
					break;
				case "v":
					size_d = 5;
					break;	
				case "s":
					size_d = 6;
					break;
				case "d":
					size_d = 7;
					break;					
				default:
					size_d = 0;
					break;
			}
				
			return size_d;	
		}

		function get_total_days_months(modify,position_month){
			
			let size_days = 0;
			let new_date = 0;

			if(modify == true){
				fecha_calendar.setMonth(position_month);
			}
			if(mes_text[fecha_calendar.getMonth()] == "Enero" || mes_text[fecha_calendar.getMonth()] == "Marzo" || mes_text[fecha_calendar.getMonth()] == "Mayo" || mes_text[fecha_calendar.getMonth()] == "Julio" || mes_text[fecha_calendar.getMonth()] == "Enero" || mes_text[fecha_calendar.getMonth()] == "Agosto" || mes_text[fecha_calendar.getMonth()] == "Octubre" || mes_text[fecha_calendar.getMonth()] == "Diciembre"){
				size_days = 32;
			}else if(mes_text[fecha_calendar.getMonth()] == "Abril" || mes_text[fecha_calendar.getMonth()] == "Junio" || mes_text[fecha_calendar.getMonth()] == "Septiembre" || mes_text[new Date().getMonth()] == "Noviembre"){
				size_days = 31;
				
			}else{
				size_days = 29;
			}
			
			return size_days;
		}

		var years = document.querySelectorAll('.year_current');

			for(let i of years){
				i.textContent = fecha_calendar.getFullYear();
			}
		


		function writeMonth(boolean,init_day,init_month){
			var table_content_months = document.querySelector('.list_btn_days');
			var all_months 			 = document.querySelectorAll('.month_');
			var size                 = get_limit_run(init_day);
			var size_months          = (boolean == true) ? get_total_days_months(true,init_month) : get_total_days_months(false,0);
			var dom  				 = "";
			table_content_months.innerHTML = "";
			
			for(let ji = 0; ji < all_months.length; ji++ ){
					if(all_months[ji].getAttribute('data-month') == fecha_calendar.getMonth()){
						index = ji;
						$('.slide_months').animate({
							'margin-left':'-'+index+'00%'
						});
					}
			}

			
			

		}
		
		writeMonth(false,day_week_init(false,0),0);


		function numerar(day__,month_load) {

			var table  = document.querySelector('.list_btn_days');
			var dom = "";
			var size = 0;
			var allmonths = document.querySelectorAll('.month_');
			table.innerHTML = "";
			var d = new Date();
			
			for(var p = 0 ; p < allmonths.length; p++){
				
				if(month_load == "default"){
					if(allmonths[p].getAttribute('data-month') == d.getMonth()){
						index = p;
						$('.slide_months').animate({
							'margin-left':'-'+index+'00%'
						});
					}
				}else{
					d.setMonth(month_load);

					if(allmonths[p].getAttribute('data-month') == d.getMonth()){
						index = p;
						$('.slide_months').animate({
							'margin-left':'-'+index+'00%'
						});

					}
				}

				
				
			}
			
			

			if(month_load=="default"){
				if(mes_text[new Date().getMonth()] == "Enero" || mes_text[new Date().getMonth()] == "Marzo" || mes_text[new Date().getMonth()] == "Mayo" || mes_text[new Date().getMonth()] == "Julio" || mes_text[new Date().getMonth()] == "Enero" || mes_text[new Date().getMonth()] == "Agosto" || mes_text[new Date().getMonth()] == "Octubre" || mes_text[new Date().getMonth()] == "Diciembre"){
					size = 32;

				}else if(mes_text[new Date().getMonth()] == "Enero" || mes_text[new Date().getMonth()] == "Abril" || mes_text[new Date().getMonth()] == "Junio" || mes_text[new Date().getMonth()] == "Septiembre" || mes_text[new Date().getMonth()] == "Noviembre"){
					size = 31;
				}else{
					size = 29;
				}
			}else{
				d.setMonth(month_load);
				if(mes_text[d.getMonth()] == "Enero" || mes_text[d.getMonth()] == "Marzo" || mes_text[d.getMonth()] == "Mayo" || mes_text[d.getMonth()] == "Julio" || mes_text[d.getMonth()] == "Enero" || mes_text[d.getMonth()] == "Agosto" || mes_text[d.getMonth()] == "Octubre" || mes_text[d.getMonth()] == "Diciembre"){
				size = 32;

				}else if(mes_text[d.getMonth()] == "Enero" || mes_text[d.getMonth()] == "Abril" || mes_text[d.getMonth()] == "Junio" || mes_text[d.getMonth()] == "Septiembre" || mes_text[d.getMonth()] == "Noviembre"){
					size = 31;
				}else{
					size = 29;
				}
			}
			
		
				var size_d = get_limit_run(day__);

				
				

				for(let j = 1; j < size_d; j++){
					table.innerHTML += `<div class="list_days box_day"></div>`;	
				}
				

			    for (i = 1; i < size; i++) {
			        let fecha = fechaPorDia(2018, i);
				    let mes = fecha.getMonth();
		
				    
				   
				    let dia = fecha.getDate()
				    let dia_semana = fecha.getDay();
				
				    if (dia == 1) {
				    	var sem = 0;
				    }

				    
				   table.innerHTML += `<div class="list_days box_day"><a href="#" class="btn_day" data-day="${dia}"><p class="number_day">${dia}</p></a></div>`;	
				    
				    

				    if (dia_semana == 6) { sem = sem + 1; }
			    }

			     
		}
		
		
		
		
		function slidemonths(direction,child){

			index = (direction == "next") ? index + 1 : index - 1;
			index = (index >= slide_months) ?  0 : index;
			index = (index < 0) ? slide_months-1 : index;
			
			
			$('.slide_months').animate({
				'margin-left':'-'+index+'00%'
			});	
			
			var date_ = new Date();
			date_.setMonth(index)
			
			writeMonth(true,day_week_init(true,index,direction),index);
		}
		$('.btn_slide').on('click', function(e){
			e.preventDefault();
			
			slidemonths($(this).attr('data-direction'));

		});


		function iterator_days(items,init,final,action){
			if(action == 'enabled'){
				var valid = false;
				for(let count = init; count < final; count++ ){

					try {
						if(typeof(items[count].children[0]) != "undefined"){
							valid = true;
						}
					} catch(e) {
						valid = false;
					}

					if(valid==true){
						items[count].children[0].classList.add('day_select');	
					}
					
					
				}
			}else{
				for(let count = init; count < final; count++ ){
					
					try {
						if(typeof(items[count].children[0]) != "undefined"){
							valid = true;
						}
					} catch(e) {
						valid = false;
					}

					if(valid==true){
						items[count].children[0].classList.remove('day_select');	
					}
						
				}
			}
			
			
		}

		function choose_all_rows(index,action){

			var all_days = document.querySelectorAll('.box_day');
			var indice = (7*index);

			if(index == 0){
				iterator_days(all_days,indice,7,action);
			}else if(index == 1){
				iterator_days(all_days,indice,7*2,action);
			}else if(index == 2){
				iterator_days(all_days,indice,7*3,action);
			}else if(index == 3){
				iterator_days(all_days,indice,7*4,action);
			}else if(index == 4){
				iterator_days(all_days,indice,7*5,action);
			}else{
				
			}
			
		}


		$.each($('.select_days'), function(iterator,item){
			$(item).on('change', function(){
				if($(item).prop('checked')){
					$(item).parent().children('label').css('background','#41BB5F');
					choose_all_rows($(item).attr('data-row'),'enabled');
					 
				    
				}else{
					$(item).parent().children('label').css('background','#FFF');
					choose_all_rows($(item).attr('data-row'),'disabled');
				}
			});
		});

		function getParameterByName(name){
		    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
		    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
		    results = regex.exec(location.search);
		    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
		}

		var contador = "";
		var days_init = "";

		

		function choose_all_days(){
			var obj = document.querySelectorAll('.b_wgreen');
			[].forEach.call(obj, item => {
				item.classList.add('b_activegreen');
			});		
		}
		var days_choose = 0;

		$('.select_all_days').on('change', function(e){
			if($(this).prop('checked')){
				choose_all_days();

			}
		});

		function addActive(element){
			element.addEventListener('click', function(e){
				e.preventDefault();
				element.classList.toggle('b_activegreen');
			});
		}
		[].forEach.call(document.querySelectorAll('.b_wgreen'), item => {
			 addActive(item);
		});

		document.querySelector('.btn_send_').addEventListener('click', e =>{
			e.preventDefault();
			days_choose = "";
			
			var code_user = getParameterByName("code");
			
			//console.log()
			[].forEach.call(document.querySelectorAll('.b_wgreen'), item => {
			 	if(item.getAttribute('class') == 'button_ b_wgreen b_wgreen_ b_activegreen'){
			 		days_choose += item.dataset.day;
			 	}
			});
			
			if(days_choose == ""){

			}else{
				$.ajax({
					url:"/centerdoggy/calendar_lender/add_days/",
					type:"POST",
					data:{code:code_user,weekday:days_choose,month:index},

					beforeSend: function(){
						$('.form_loader').css('visibility','visible');
					},

					complete: function(){
						$('.form_loader').css('visibility','hidden');
					},
					success: function(response){
						console.log(response);
						if(response == "failed" || response == null || response == "undefined"){

						}else{
							// var data = JSON.parse(response);
							// var string = "";
							// data.map((item,index) => {
								
							// 	if(index > 0){
							// 		string +="-"+item.id_day;
							// 	}else{
							// 		string += item.id_day;
							// 	}
							// });

							// console.log(string);
							window.location = response;

						}
					}

		
				});
			}
		});
	</script>
</body>
</html>