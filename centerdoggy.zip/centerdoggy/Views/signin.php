<?php 
session_start();
if(isset($_SESSION['email']) || isset($_SESSION['id_user'])){
	if($_SESSION['location'] == "users"){
		header('Location: http://localhost:8089/centerdoggy/portal/');
	}else if($_SESSIO['location'] == "owners"){
		header('Location: http://localhost:8089/centerdoggy/portal_owners/');
	}else{
		header('Location: http://localhost:8089/centerdoggy/portal_lenders/');
	}
}else{
	session_destroy();
	unset($_SESSION['email']);
	unset($_SESSION['id_user']);
}


 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header">
	<a href="/centerdoggy/" class="logo_icono" style="position:absolute;left:15px;top:10px;z-index: 200;">
		<h1 class="name_company">PET_CENTER</h1>
	</a>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="/centerdoggy/" class="link_section">Nuestros servicios</a></li>
			<li class="list_"><a href="/centerdoggy/" class="link_section">Como funciona</a></li>
			<li class="list_"><div class="input_button"><a href="/centerdoggy/signin/" class=" button_ b_green">Iniciar Sesión</a></div></li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_ bg_container_gray bg_complete">
		<div class="content_info mb-x50">
			<span class="alert_">Upps! Ha ocurrido un error dificilisimo</span>
			<h1 class="title_center_ borderb bminwidth">¡INICIA SESIÓN!</h1>
			<p class="description_center_">Ven y conoce lo que succede dentro de petcenter, no te lo pierdas</p>
			<div class="container_form form_center form_white form_shadow w-x50 m-x50">
				<form action="/centerdoggy/signin/signin/" class="form_" method="POST">
					<div class="input_group"><input type="text" name="email" id="email" class="textfield field_email" placeholder="Email"></div>
					<div class="input_group"><input type="password" name="password" id="password" class="textfield field_password" placeholder="Password"></div>
					<div class="input_group">
						<div class="input_button">
							<button type="submit" class="button_ b_green b_sndl">Iniciar Sesión</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		<div class="content_info bg_gray bg_container_gray">
			<footer class="footer">
				<div class="pane_info">
					<a href="#" class="logo_icono">
						<h1 class="name_company">PET_CENTER</h1>
					</a>
					<p class="short_info">Derechos reservados 2018 SeitConsultores. Hecho con ♥ en Colombia</p>
				</div>
				<div class="pane_info pane_division">
					<div class="panes_">
						<h4 class="type_">Producto</h4>
						<li class="list_option"><a href="#" class="section">¿Por que Pet_center?</a></li>
						<li class="list_option"><a href="#" class="section">Planes y precios</a></li>
					</div>
					<div class="panes_">
						<h4 class="type_">Recursos</h4>
						<li class="list_option"><a href="#" class="section">Centro de ayuda</a></li>
						<li class="list_option"><a href="#" class="section">Guias</a></li>
					</div>
					<div class="panes_">
						<h4 class="type_">Compañia</h4>
						<li class="list_option"><a href="#" class="section">Acerca de</a></li>
						<li class="list_option"><a href="#" class="section">Empleo</a></li>
					</div>
				</div>
			</footer>
		</div>
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>
	<script>
		var button_l = document.querySelector('.b_sndl');

		button_l.addEventListener("click", function(e){
			e.preventDefault();
			var email    =  document.querySelector('.field_email'),
				password =  document.querySelector('.field_password');

				if(email.value == "" && password.value == ""){
					document.querySelector('.alert_').innerHTML = "<strong>Upps!</strong> datos incompletos, por favor completalos y intentalo de nuevo";
					document.querySelector('.alert_').classList.remove('alert_success');
					document.querySelector('.alert_').classList.add('alert_error');
				}else if(email.value == ""){
					document.querySelector('.alert_').innerHTML = "<strong>Upps!</strong> datos incompletos, por favor completalos y intentalo de nuevo";
					document.querySelector('.alert_').classList.remove('alert_success');
					document.querySelector('.alert_').classList.add('alert_error');
				}else if(password.value == ""){
					document.querySelector('.alert_').innerHTML = "<strong>Upps!</strong> datos incompletos, por favor completalos y intentalo de nuevo";
					document.querySelector('.alert_').classList.remove('alert_success');
					document.querySelector('.alert_').classList.add('alert_error');
				}else{
					email = email.value;
					password = password.value;
					var data = new FormData();
					data.append('email',email);
					data.append('password',password);
					
					fetch("/centerdoggy/signin/signin/", {
						method: 'POST',
						body:data
					})
					.then(response => {
						return response.json();
					})
					.then(result => {
						console.log(result);
						if(result.res == "failed"){
							document.querySelector('.alert_').innerHTML = "<strong>Upps!</strong> datos incorrectos, verificalos y intenta de nuevo, para iniciar sesion";
						document.querySelector('.alert_').classList.remove('alert_success');
						document.querySelector('.alert_').classList.add('alert_error');
						}else{
							window.location = result.URL;
						}
					});
				}
		});
	</script>
</body>
</html>