<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header">
	<a href="/centerdoggy/" class="logo_icono" style="position:absolute;left:15px;top:10px;z-index: 200;">
		<h1 class="name_company">PET_CENTER</h1>
	</a>
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_"><a href="/centerdoggy/" class="link_section">Nuestros servicios</a></li>
			<li class="list_"><a href="/centerdoggy/" class="link_section">Como funciona</a></li>
			<li class="list_"><div class="input_button"><a href="/centerdoggy/signin/" class=" button_ b_green">Iniciar Sesión</a></div></li>
			
		</ul>
	</nav>
</header>
<body>
	<div class="container_ bg_container_gray ">
		<div class="content_info mb-x50">
			<span class="alert_">Upps! Ha ocurrido un error dificilisimo</span>
			<h1 class="title_center_ borderb">¡Registrate ahora!</h1>
			<p class="description_center_">Si eres propietario de una mascota,te invitamos a que haga parte de este centro de atencion</p>
			<div class="container_form form_center form_white form_shadow w-x50">
				<form action="/centerdoggy/register_owner/add_owner/" class="form_">
					<div class="input_group"><input type="text" name="" id="field_name" class="textfield field_name" placeholder="Nombre y apellido"></div>
					<div class="input_group">
						<select name="" id="field_sex" class="textfield field_sex">
							<option value="default">Selecciona tu sexo</option>
							<option value="Hombre">Hombre</option>
							<option value="Mujer">Mujer</option>
						</select>
					</div>
					<div class="input_group"><input type="text" name="" id="field_email" class="textfield field_email" placeholder="Correo electronico"></div>
					<div class="input_group"><input type="password" name="field_password" id="" class="textfield field_password" placeholder="Password"></div>
					<div class="input_group">
						<div class="input_button">
							<button type="submit" class="button_ b_green btn_send_">registrarme</button>
						</div>
					</div>
				</form>
				<div class="form_loader">
	              <div class="container_loader">
	                  <div class="bar_loader">
	                    <div class="loader"></div>
	                      <img src="<?php echo rute__folder;?>img/padlock.svg" alt="">
	                  </div>
	                  <p class="info_">Estamos registrandote...</p>
	              </div>
          		</div>
			</div>
		</div>
		<div class="content_info bg_gray bg_container_gray">
			<footer class="footer">
				<div class="pane_info">
					<a href="#" class="logo_icono">
						<h1 class="name_company">PET_CENTER</h1>
					</a>
					<p class="short_info">Derechos reservados 2018 SeitConsultores. Hecho con ♥ en Colombia</p>
				</div>
				<div class="pane_info pane_division">
					<div class="panes_">
						<h4 class="type_">Producto</h4>
						<li class="list_option"><a href="#" class="section">¿Por que Pet_center?</a></li>
						<li class="list_option"><a href="#" class="section">Planes y precios</a></li>
					</div>
					<div class="panes_">
						<h4 class="type_">Recursos</h4>
						<li class="list_option"><a href="#" class="section">Centro de ayuda</a></li>
						<li class="list_option"><a href="#" class="section">Guias</a></li>
					</div>
					<div class="panes_">
						<h4 class="type_">Compañia</h4>
						<li class="list_option"><a href="#" class="section">Acerca de</a></li>
						<li class="list_option"><a href="#" class="section">Empleo</a></li>
					</div>
				</div>
			</footer>
		</div>
	</div>
	<script src="<?php echo rute__folder;?>js/jquery-3.3.1.min.js"></script>	
	<script src="<?php echo rute__folder;?>js/module_init.js"></script>
</body>
</html>