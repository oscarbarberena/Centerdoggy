<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Center Doggy</title>
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>icomoon_/style.css">
	<link rel="stylesheet" href="<?php echo rute__folder;?>css/style.css">
</head>
<header class="main_header border-bottom">
	<nav class="nav_">
		<ul class="content_items">
			<li class="list_ right-30"><div class="input_button"><a href="signin.html" class=" button_  b_notification"><i class="icon-bell"></i></a></div></li>
			<li class="list_ right-30"><a href="#" class="link_section">Jhon Murillo Mendez</a></li>		
		</ul>
	</nav>
</header>
<body>
	<div class="container_">
		<div class="pane_menu_navigation">
			<div class="section_logo">
				<a href="#" class="logo_portal"><i class="icon-dog-paw"></i></a>
			</div>
			<div class="navigation">
				<li class="list_"><a href="#" class="section_ active"><i class="icon-home"></i></a></li>
				<li class="list_"><a href="/centerdoggy/lenders/" class="section_"><i class="icon-avatar"></i></a></li>
				<li class="list_"><a href="/centerdoggy/pets/" class="section_"><i class="icon-zynga-logotype"></i></a></li>
				<li class="list_"><a href="/centerdoggy/veterinarians_/" class="section_"><i class="icon-pet"></i></a></li>
				<li class="list_"><a href="/centerdoggy/offices_/" class="section_"><i class="icon-hotel"></i></a></li>
			</div>
		</div>
		<div class="content_info pane_section">
			<div class="content_title center p-x30 m_bottomx60">
				<h2 class="title_ t_green">Estos los Prestadores, que trabajan con nosotros</h2>
				<p class="info_">Selecciona la mejor opción para tu mascota, recuerda hacer la reserva ya!</p>
			</div>
			<div class="container_search">
				<div class="input_group">
					<input type="text" name="" id="" class="textfield" placeholder="Busca a un cuidador...">
				</div>
				<div class="input_controls">
					<button type="button" class="controls_ btn_controls"><span aria-label="Más acciones" class="recents-item__actions-button button-secondary mc-overflow-button mc-button mc-button-secondary"><span class="mc-button-content"><svg width="32" height="32" viewBox="0 0 32 32" class="mc-icon-template-actionable mc-overflow-button-icon"><g fill="none" fill-rule="evenodd"><g fill="#637282"><circle cx="10.5" cy="16.5" r="1.5"></circle><circle cx="15.5" cy="16.5" r="1.5"></circle><circle cx="20.5" cy="16.5" r="1.5"></circle></g></g></svg></span></span></button>
					<div class="sub_options_ sub_controls_">
		                <div class="list_option">
		                    <a href="/centerdoggy/my_pets/add/" class="link_">Agregar</a>
		                </div>
		                <div class="list_option">
		                  <a href="#" class="link_">Eliminar</a>
		                </div>
            		</div>
				</div>
				<div class="input_button">
					<button type="button" class="button_ b_green">Buscar</button>
				</div>
			</div>

		</div>
		
	</div>
</body>
</html>